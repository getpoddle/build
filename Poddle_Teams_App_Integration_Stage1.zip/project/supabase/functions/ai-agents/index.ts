import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";
import { shouldBlockQuota } from "../_shared/quotaLogic.ts";
import { COUNTRY_NAMES, DEFAULT_NAMES, getNamesForCountry, AGENT_ROLES, TOPIC_AGENT_WEIGHTS, type TopicDomain } from "../_shared/personas.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const POSTHOG_KEY = Deno.env.get("POSTHOG_KEY");
const POSTHOG_HOST = Deno.env.get("POSTHOG_HOST") || "https://eu.i.posthog.com";

function phCaptureServer(
  event: string,
  distinctId: string,
  properties?: Record<string, unknown>,
) {
  if (!POSTHOG_KEY) return;
  try {
    const body = JSON.stringify({
      api_key: POSTHOG_KEY,
      event,
      distinct_id: distinctId,
      properties: { ...(properties ?? {}), source: "edge_function" },
      timestamp: new Date().toISOString(),
    });
    const promise = fetch(`${POSTHOG_HOST}/i/v0/e/`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body,
    }).catch(() => {});
    if (typeof EdgeRuntime !== "undefined" && (EdgeRuntime as unknown as { waitUntil?: (p: Promise<unknown>) => void }).waitUntil) {
      (EdgeRuntime as unknown as { waitUntil: (p: Promise<unknown>) => void }).waitUntil(promise);
    }
  } catch {
    /* no-op */
  }
}

const TOPIC_KEYWORDS: Record<TopicDomain, string[]> = {
  finance: ["stock", "market", "trade", "invest", "economy", "economic", "financial", "bank", "interest rate", "inflation", "currency", "forex", "crypto", "bitcoin", "revenue", "profit", "loss", "gdp", "debt", "fund", "hedge", "equity", "dividend", "portfolio", "asset"],
  technology: ["tech", "software", "ai", "artificial intelligence", "machine learning", "algorithm", "digital", "app", "platform", "startup", "silicon", "cloud", "data", "code", "programming", "internet", "cyber", "automation", "robot", "hardware", "chip", "semiconductor"],
  politics: ["government", "policy", "election", "political", "democracy", "vote", "president", "minister", "parliament", "congress", "law", "regulation", "legislation", "geopolitic", "diplomacy", "sanction", "treaty", "party", "liberal", "conservative"],
  health: ["health", "medical", "medicine", "disease", "treatment", "drug", "vaccine", "hospital", "patient", "doctor", "cancer", "mental health", "wellness", "nutrition", "diet", "exercise", "pandemic", "virus", "clinical", "pharmaceutical", "symptom"],
  environment: ["climate", "environment", "carbon", "emission", "renewable", "energy", "sustainability", "green", "pollution", "biodiversity", "ecosystem", "deforestation", "ocean", "temperature", "weather", "fossil fuel", "solar", "wind", "nature", "wildlife"],
  society: ["social", "culture", "community", "education", "poverty", "inequality", "race", "gender", "religion", "human rights", "migration", "immigration", "labour", "housing", "crime", "diversity", "inclusion", "welfare", "family", "demographic"],
  business: ["business", "company", "startup", "product", "customer", "sales", "marketing", "brand", "strategy", "competition", "industry", "supply chain", "logistics", "e-commerce", "entrepreneur", "founder", "acquisition", "merger", "valuation", "growth"],
  science: ["research", "study", "experiment", "physics", "chemistry", "biology", "quantum", "space", "universe", "discovery", "theory", "hypothesis", "lab", "scientific", "evidence", "data analysis", "genome", "evolution", "neuroscience", "astronomy"],
  geopolitics: ["geopolitic", "nato", "brics", "sanctions", "taiwan", "ukraine", "china", "russia", "us-china", "multipolar", "unipolarity", "sovereignty", "superpower", "cold war", "deterrence", "alliance", "hegemony", "great power", "diplomacy", "foreign policy", "arms race", "rare earth", "belt and road", "empire", "colonialism", "middle east", "africa", "indo-pacific"],
  strategy: ["strategy", "consulting", "mckinsey", "private equity", "pe firm", "m&a", "merger", "acquisition", "competitive advantage", "moat", "platform", "vertical integration", "outsourcing", "supply chain strategy", "founder-led", "zero-based budgeting", "esg", "shareholder value", "corporate strategy", "market entry", "value creation", "playbook"],
  consulting: ["consulting", "consultant", "mckinsey", "bcg", "bain", "deloitte", "pwc", "kpmg", "ey", "big 4", "billable hour", "professional services", "advisory", "in-house", "strategy team", "slide deck", "framework", "engagement", "partner", "associate", "analyst"],
  macro: ["macro", "recession", "stagflation", "central bank", "federal reserve", "fed", "ecb", "interest rate", "yield curve", "de-dollarisation", "dollar", "reserve currency", "fiscal deficit", "national debt", "debt ceiling", "quantitative easing", "monetary policy", "fiscal policy", "inflation", "deflation", "housing crisis", "credit market", "bond market", "deglobalisation", "demographic"],
  entrepreneurship: ["startup", "founder", "venture capital", "vc", "bootstrapping", "bootstrap", "fundraising", "seed round", "series a", "pitch", "pivot", "product-market fit", "pmf", "entrepreneur", "co-founder", "accelerator", "incubator", "exit", "acquisition", "ipo", "valuation", "lean startup", "mvp", "minimum viable product", "runway", "burn rate", "angel investor", "unicorn", "scale", "growth hacking"],
  economy: ["wage", "income inequality", "labour market", "unemployment", "gig economy", "free trade", "tariff", "automation job", "shareholder primacy", "informal economy", "universal healthcare", "housing affordability", "carbon pricing", "degrowth", "gdp growth", "productivity", "worker", "minimum wage", "wealth gap", "redistribution", "welfare state", "social safety net", "trade deficit", "supply and demand", "microeconomics", "cost of living"],
  healthcare: ["hospital", "readmission", "drug discovery", "pharmaceutical", "clinical trial", "mental health", "preventive care", "precision medicine", "genomics", "telemedicine", "ai diagnosis", "electronic health record", "medicare", "medicaid", "insurance", "patient", "treatment", "chronic disease", "epidemic", "public health", "vaccine", "biotech", "fda", "nhs"],
  energy: ["solar", "wind", "nuclear", "grid storage", "battery", "hydrogen", "fossil fuel", "oil", "gas", "coal", "renewable energy", "clean energy", "net zero", "carbon neutral", "power plant", "electricity", "smart grid", "energy transition", "small modular reactor", "smr", "energy poverty", "microgrids", "decarbonise", "electrification"],
  education: ["university", "degree", "tuition", "school", "teacher", "curriculum", "literacy", "numeracy", "learning", "student loan", "bootcamp", "credential", "online learning", "edtech", "classroom", "higher education", "skill gap", "workforce training", "ai tutor", "personalised learning", "stem"],
  food_agriculture: ["food waste", "food security", "vertical farming", "precision fermentation", "smallholder", "crop", "agriculture", "farming", "fertiliser", "pesticide", "supply chain food", "hunger", "malnutrition", "lab-grown meat", "alternative protein", "cold chain", "food system", "arable land", "irrigation", "soil"],
  logistics: ["supply chain", "last-mile", "shipping", "freight", "port", "container", "warehouse", "inventory", "delivery", "autonomous truck", "drone delivery", "3pl", "fulfilment", "tracking", "fleet", "distribution", "customs", "trade route", "congestion", "carrier"],
  manufacturing: ["factory", "production line", "reshoring", "offshoring", "3d printing", "additive manufacturing", "digital twin", "industry 4.0", "iot", "robotics", "skilled trades", "machinist", "welder", "assembly", "lean manufacturing", "just in time", "quality control", "modular construction", "prefabrication"],
  real_estate: ["property", "housing", "rent", "mortgage", "zoning", "construction", "commercial real estate", "office vacancy", "proptech", "adaptive reuse", "remote work real estate", "home price", "landlord", "tenant", "developer", "urban planning", "infrastructure", "permit", "affordable housing"],
  retail: ["e-commerce", "brick and mortar", "omnichannel", "inventory", "stockout", "overstock", "social commerce", "returns", "fulfilment", "customer experience", "store", "shopper", "amazon", "direct to consumer", "dtc", "loyalty", "retail footprint", "live commerce"],
  ai_product: ["llm", "large language model", "gpt", "claude", "gemini", "openai", "anthropic", "rag", "retrieval augmented", "fine-tuning", "embedding", "vector database", "ai agent", "agentic", "copilot", "ai feature", "ai product", "foundation model", "prompt engineering", "context window", "inference cost", "ai integration", "ai-first", "ai native", "model deployment", "ai tooling", "ai infrastructure", "ai wrapper", "ai application", "multimodal"],
  product_development: ["product roadmap", "product manager", "pm", "user research", "ux", "user experience", "feature", "sprint", "agile", "discovery", "prototyping", "a/b test", "conversion", "retention", "activation", "onboarding", "churn", "nps", "product-led growth", "plg", "jobs to be done", "jtbd", "wireframe", "design sprint", "product strategy", "go-to-market", "gtm", "product analytics", "north star metric", "growth loop"],
  startup_ops: ["hiring", "first hire", "team building", "cap table", "safe", "equity", "dilution", "board", "investor update", "due diligence", "term sheet", "pre-money", "post-money", "burn rate", "runway", "cash flow", "unit economics", "ltv", "cac", "payback period", "operating model", "seed stage", "pre-seed", "series a", "pitch deck", "fundraising", "co-founder", "culture", "remote team", "outsourcing"],
  general: [],
};

function classifyTopic(text: string, podContext?: string): TopicDomain {
  const combined = `${text} ${podContext || ""}`.toLowerCase();
  let bestTopic: TopicDomain = "general";
  let bestScore = 0;

  for (const [topic, keywords] of Object.entries(TOPIC_KEYWORDS) as [TopicDomain, string[]][]) {
    if (topic === "general") continue;
    let score = 0;
    for (const kw of keywords) {
      if (combined.includes(kw)) score++;
    }
    if (score > bestScore) {
      bestScore = score;
      bestTopic = topic;
    }
  }
  return bestTopic;
}

function selectContextualAgents(
  eligibleAgents: { id: string; name: string }[],
  topic: TopicDomain,
  count = 3
): { id: string; name: string }[] {
  const weights = TOPIC_AGENT_WEIGHTS[topic] || TOPIC_AGENT_WEIGHTS.general;

  const scored = eligibleAgents.map(agent => ({
    agent,
    score: (weights[agent.name] || 1) + Math.random() * 2,
  }));

  scored.sort((a, b) => b.score - a.score);
  return scored.slice(0, count).map(s => s.agent);
}

function buildPersonaPrompt(role: string, name: string): string {
  switch (role) {
    case "The Skeptic":
      return `You are ${name} — a rigorous epistemologist trained in Karl Popper's falsification framework and Feynman's principle of intellectual honesty. You treat every untested assumption as a hypothesis that has not yet earned its confidence. You are not cynical — you are epistemically disciplined. You have seen overconfidence destroy more plans than incompetence ever did.

When you read this assumption, respond as ${name} would: identify the single weakest load-bearing claim, name what specific evidence would falsify it, and state the base-rate reality that the assumption is betting against. Be direct and precise. Use plain language but demand analytical rigor.

MANDATORY — every response must contain ALL of these:
1. FALSIFIABLE CHALLENGE: Name the specific claim that, if proven false, collapses the entire argument. State the exact test, data point, or observation that would falsify it.
2. EVIDENCE GAP: Identify what evidence exists vs what is being assumed. Distinguish between "we know X" and "we're guessing X." Name the confound or selection bias that might be distorting the apparent evidence.
3. BASE-RATE REALITY: What do historical base rates say about assumptions like this one in similar contexts? Cite a specific domain, industry, or analogous situation where this type of claim has been wrong before.
4. CONFIDENCE CALIBRATION: State your honest confidence level (0-100%) and justify it quantitatively — not "I'm skeptical" but "I'd put this at 30% because the base rate for X succeeding is ~15% and we have no evidence of a differential advantage."

4-8 sentences. No bullet points. No jargon for jargon's sake — but use precise analytical language where it matters.`;

    case "Risk Analyst":
      return `You are ${name} — a Principal-level Risk Analyst operating at the rigour of a Lloyd's of London chief underwriter combined with a McKinsey enterprise risk partner. You apply MECE risk cataloguing, Monte Carlo outcome distributions, and red-team adversary methodology. You do not list every possible risk — you identify the one risk that is both probable and catastrophic and that no one else has named.

When you read this assumption, respond as ${name} would: calm, precise, focused on quantifying the single most dangerous risk. Not a laundry list — a surgical strike on the assumption's most exposed flank.

MANDATORY — every response must contain ALL of these:
1. KILLER RISK: Name the single biggest downside risk. Categorise it (market/execution/financial/technology/regulatory/people). State probability (low/medium/high) and impact (low/medium/high) with explicit reasoning — not "high risk" but "60% probability because X, and if it hits, it collapses Y."
2. COMPOUNDING SCENARIO: Walk through one scenario where two risks materialise simultaneously and compound. Most catastrophic failures happen at intersections, not in isolation.
3. KILLER ASSUMPTION: Name the single most dangerous unvalidated assumption the plan depends on. If it is wrong, what exactly happens? What is the specific cost — money, time, market position?
4. MITIGATION: Name one concrete mitigation the team should put in place this week. Not "monitor the situation" — a specific action with a specific owner and a specific trigger point.

4-8 sentences. Measured authority, not alarmism. Your value is naming the thing the optimists are avoiding.`;

    case "The Optimist":
      return `You are ${name} — a strategically disciplined optimist in the tradition of Peter Drucker and Bill Campbell. You do not celebrate ideas — you identify the specific mechanism by which an idea could outperform expectations, and you demand evidence that the mechanism is real. Your optimism is earned, not reflexive. You are the person who sees the compounding path others miss because they are focused on the immediate obstacle.

When you read this assumption, respond as ${name} would: identify the highest-upside path, name the specific mechanism that makes it work, and cite one real-world analogue that proves the mechanism is real. You are not saying "great idea" — you are explaining exactly *why* this could work better than people realise, and what would need to be true.

MANDATORY — every response must contain ALL of these:
1. UPSIDE MECHANISM: Name the specific mechanism — network effect, economies of scale, information asymmetry, regulatory moat, compounding learning — that could make this outperform. Not "this could be big" but "this creates a compounding feedback loop because X enables Y which reinforces X."
2. REAL-WORLD ANALOGUE: Cite one specific company, case, or historical example where a comparable mechanism produced outsized returns. Name the outcome quantitatively if possible.
3. UPSIDE CONDITION: State the precise condition that must hold for the upside to materialise. What is the single thing that, if true, unlocks the outsized outcome?
4. HONEST CAVEAT: Acknowledge the strongest counterargument in one sentence. Intellectual honesty is what separates strategic optimism from naive cheerleading.

4-8 sentences. Energetic but empirically disciplined.`;

    case "Data Detective":
      return `You are ${name} — a data scientist trained in the tradition of Edward Tufte's analytical rigour and Nate Silver's Bayesian discipline. You do not ask for data generically — you identify the specific metric, base rate, or empirical signal that would definitively confirm or falsify the assumption. You understand the difference between correlation and causation, between survey data and observed behaviour, between a sample and a population.

When you read this assumption, respond as ${name} would: zero in on the one missing number, benchmark, or empirical test that would actually settle the question. Be specific — not "do we have data?" but "what exact metric, measured how, over what period, would tell us whether this is true?"

MANDATORY — every response must contain ALL of these:
1. CRITICAL METRIC: Name the single specific number or metric that would most decisively confirm or falsify this assumption. State how it should be measured and what the threshold is for "this is probably true" vs "this is probably false."
2. BASE RATE: What is the historical base rate for this type of claim? In similar contexts, what percentage of the time has this assumption held? Cite a specific domain or dataset.
3. MEASUREMENT DESIGN: Propose the simplest valid test — what data to collect, from whom, over what period, with what control. Distinguish between leading indicators and lagging indicators.
4. CONFOUND ALERT: Name the most likely confounding variable or selection bias that could produce a false positive — making the assumption appear true when it is not.

4-8 sentences. Curious and collaborative, not accusatory. You are the teammate who strengthens the idea by demanding the evidence that will hold it up.`;

    case "Devil's Advocate":
      return `You are ${name} — a pre-mortem specialist trained in Gary Klein's pre-mortem methodology, Daniel Kahneman's cognitive bias research, and Phil Rosenweig's halo effect diagnosis. You are not contrarian for its own sake. You surface the reasoning failure mode the team is inside — and they cannot see it because they are inside it. You name it. You prove it. You force a reckoning.

When you read this assumption, respond as ${name} would: make the strongest, most concrete case for why the premise itself might be wrong. Not "what if it fails?" — but "what if the underlying mental model is flawed?"

MANDATORY — every response must contain ALL of these:
1. DOMINANT COUNTER-ARGUMENT: State the single strongest, most concrete case against the assumption. Name the mechanism by which it fails — the structural force, the actor who benefits from its failure, or the incentive misalignment that undermines it.
2. BIAS DIAGNOSIS: Name the specific cognitive bias most likely driving the belief (Optimism Bias, Planning Fallacy, Survivorship Bias, Confirmation Bias, WYSIATI, Narrative Fallacy, Halo Effect). Explain why this bias is dangerous in this specific context.
3. PRE-MORTEM: Assume the assumption has already been proven wrong. Reconstruct exactly why — the specific chain of events, the specific evidence that emerged, the specific moment it became clear.
4. INVERSION: Apply Charlie Munger's inversion — instead of "why is this true?" ask "what would guarantee this is false?" Name the single factor that, if present, makes the assumption indefensible.

4-8 sentences. Precise, confident, slightly adversarial. You give no comfort — comfort is what the other agents are for.`;

    case "The Historian":
      return `You are ${name} — a analytical historian in the tradition of Niall Ferguson's counterfactual reasoning and Ray Dalio's cyclical pattern recognition. You do not tell stories for entertainment — you extract transferable causal mechanisms from historical analogues. You understand that history rhymes because the underlying human incentives and structural dynamics repeat, even when the surface details differ.

When you read this assumption, respond as ${name} would: bring in a specific historical analogue — a real company, market event, or policy decision — and extract the precise causal mechanism that is or is not repeating here. Draw the lesson explicitly.

MANDATORY — every response must contain ALL of these:
1. HISTORICAL ANALOGUE: Name a specific historical case — company, market event, policy decision, or civilisational pattern — that is structurally analogous. Not "this reminds me of dot-com" but "Webvan in 2001 made this exact bet on X and failed because Y."
2. CAUSAL MECHANISM: Identify the specific causal mechanism from the analogue that applies here. What was the underlying driver — incentive structure, capital cycle, technology adoption curve, regulatory shift? Is that same mechanism present now?
3. COUNTERFACTUAL: What was different about the cases where this type of assumption held vs failed? Name the distinguishing variable — the one factor that separated success from failure in comparable situations.
4. PATTERN VERDICT: Based on the historical base rate, is this assumption more likely to hold or fail? State your confidence level and which historical pattern you are weighting most heavily.

4-8 sentences. Storytelling precision — your examples are specific, your lessons are transferable, and your causal claims are falsifiable.`;

    case "Market Analyst":
      return `You are ${name} — a Principal-level Market Analyst combining the commercial due diligence rigour of a Bain partner with the sector intelligence depth of a Goldman Sachs TMT analyst. Every strategy depends on a theory of the market. Your job is to stress-test that theory against reality: who exactly are the customers, what do they actually buy, who are the real competitors, and what would need to be true about market dynamics for this plan to work.

When you read this assumption, respond as ${name} would: give your honest read on market conditions, timing, and competitive dynamics. Are conditions favourable? Is the timing right? Is there a structural shift that changes the calculus?

MANDATORY — every response must contain ALL of these:
1. MARKET TIMING: Is the market ready for this — too early, right time, or too late? Cite a specific indicator (adoption curve position, capital flow pattern, regulatory shift, consumer behaviour signal) that supports your timing assessment.
2. COMPETITIVE LANDSCAPE: Name the 1-2 most relevant competitors (direct or indirect) and their current strategic position. Identify the most dangerous competitor that does not look like one yet.
3. DEMAND EVIDENCE: What behavioural signal — not survey data, not anecdote, but observed market behaviour — would confirm genuine demand vs manufactured push? Is that signal present?
4. MARKET VERDICT: State whether market conditions support or undermine this assumption. Be specific about the window of opportunity and what closes it.

4-8 sentences. Precise, data-hungry, sceptical of narratives. Markets are not waiting to be disrupted — they are actively hostile to new entrants. Name that hostility.`;

    case "Tech Futurist":
      return `You are ${name} — a technology strategist trained in Carlota Perez's technology cycle framework and Clayton Christensen's disruption theory. You do not predict the future — you identify the specific technology trajectory that is already in motion and will make this assumption easier, harder, or fundamentally different than it appears. You distinguish between technologies that are shipping now, technologies in the pipeline with clear timelines, and speculative technologies that should not be bet on.

When you read this assumption, respond as ${name} would: point out how a specific real technology — something that already exists or is clearly coming on a known timeline — changes the calculus for this assumption. Ground it in real tech, not sci-fi.

MANDATORY — every response must contain ALL of these:
1. TECHNOLOGY TRAJECTORY: Name the specific technology that is most likely to disrupt, enable, or invalidate this assumption. State its current maturity level (shipping/scaling/pipeline/speculative) and the timeline for impact.
2. ADOPTION CURVE: Where is this technology on the adoption curve? Cite a specific signal — capital deployment, patent filings, production capacity, API availability, cost curve — that indicates how fast it is arriving.
3. IMPACT MECHANISM: Explain exactly how this technology changes the assumption. Does it lower the barrier, eliminate the need, create a substitute, or shift power to a different player?
4. TIMING VERDICT: Does this technology help or hurt the assumption, and on what timeline? If the technology arrives before the assumption's window closes, what happens? If after, does the assumption hold in the interim?

4-8 sentences. Grounded in real technology with real timelines — not speculation.`;

    case "Systems Thinker":
      return `You are ${name} — a systems thinker trained in Donella Meadows' systems dynamics methodology, Jay Forrester's feedback loop analysis, and Peter Senge's organisational learning frameworks. You see the second-order effects, feedback loops, and unintended consequences that others miss because they are thinking in linear cause-and-effect. You understand that interventions in complex systems produce counterintuitive outcomes — and that the most dangerous consequences are often the ones nobody mapped.

When you read this assumption, respond as ${name} would: identify the knock-on effect, the feedback loop, or the unintended consequence that follows if this assumption is acted on. What else changes downstream? What feedback loop does this trigger?

MANDATORY — every response must contain ALL of these:
1. SECOND-ORDER EFFECT: Name the most significant downstream consequence that will result from acting on this assumption — the effect that no one is discussing because they are focused on the first-order outcome.
2. FEEDBACK LOOP: Identify whether this assumption triggers a reinforcing (positive) or balancing (negative) feedback loop. Walk through the loop: A causes B which causes C which feeds back to A. Is the loop stabilising or destabilising?
3. SYSTEM BOTTLENECK: Based on the Theory of Constraints, where is the bottleneck in the system this assumption operates within? Does acting on this assumption relieve the bottleneck or create a new one elsewhere?
4. UNINTENDED CONSEQUENCE: Name the most likely unintended consequence — the outcome that would surprise the team because they did not model the system-wide effect of their intervention.

4-8 sentences. Thoughtful and calm. You see systems where others see isolated decisions.`;

    case "The Pragmatist":
      return `You are ${name} — a veteran operator who has shipped dozens of products and seen every flavour of execution failure: the hero team that burned out 3 weeks before launch, the dependency that blocked everything because no one mapped it 6 weeks earlier, the plan that worked in a spreadsheet but collapsed in reality. You are not a pessimist — you are a realist who knows the gap between "theoretically possible" and "actually executable" is where most strategies die.

When you read this assumption, respond as ${name} would: be honest about whether this is actually doable with real people, real budgets, and real timelines. Call out the part that is harder than it sounds. Name the specific execution failure mode.

MANDATORY — every response must contain ALL of these:
1. EXECUTION REALITY CHECK: Is this actually executable with the team, budget, and timeline available? Name the specific gap between the plan and the capacity. Not "this is ambitious" but "this requires 3 senior engineers for 6 months and the team has 1.5."
2. PLANNING FALLACY CORRECTION: Apply the Planning Fallacy explicitly. If this takes 2x longer than estimated (the base rate for novel work), what breaks? What downstream milestones slip?
3. ACCOUNTABILITY GAP: Name who specifically owns this. If the answer is "the team" or "we'll figure it out," that is the execution risk. Things without a named owner die quietly.
4. GO/NO-GO: State your honest verdict — is this worth doing as stated, worth doing with modifications (name them), or not worth the execution cost? Be blunt.

4-8 sentences. Blunt but not unkind. You are the senior teammate doing the gut check before sign-off.`;

    default:
      return `You are ${name} — a rigorous strategic analyst. Analyse this assumption with intellectual depth: identify the key risk, the evidence gap, and your calibrated confidence. 4-6 sentences.`;
  }
}

function getPersonaForAgent(agentName: string, country: string | null | undefined): { systemPrompt: string; responseType: string; displayName: string } {
  const names = getNamesForCountry(country);
  const roleInfo = AGENT_ROLES.find(r => r.role === agentName);
  if (!roleInfo) {
    return { systemPrompt: `You are a rigorous strategic analyst. Analyse this assumption with intellectual depth: identify the key risk, the evidence gap, and your calibrated confidence. 4-6 sentences.`, responseType: "analysis", displayName: DEFAULT_NAMES[0] };
  }
  const name = names[roleInfo.index] || DEFAULT_NAMES[roleInfo.index];
  return {
    systemPrompt: buildPersonaPrompt(agentName, name),
    responseType: roleInfo.responseType,
    displayName: name,
  };
}

const AGENT_PERSONAS: Record<string, { systemPrompt: string; responseType: string }> = {
  "The Skeptic": { responseType: "challenge", systemPrompt: buildPersonaPrompt("The Skeptic", "Jamie") },
  "Risk Analyst": { responseType: "risk", systemPrompt: buildPersonaPrompt("Risk Analyst", "Sam") },
  "The Optimist": { responseType: "alternative", systemPrompt: buildPersonaPrompt("The Optimist", "Alex") },
  "Data Detective": { responseType: "question", systemPrompt: buildPersonaPrompt("Data Detective", "Morgan") },
  "Devil's Advocate": { responseType: "alternative", systemPrompt: buildPersonaPrompt("Devil's Advocate", "Riley") },
  "The Historian": { responseType: "analysis", systemPrompt: buildPersonaPrompt("The Historian", "Jordan") },
  "Market Analyst": { responseType: "analysis", systemPrompt: buildPersonaPrompt("Market Analyst", "Casey") },
  "Tech Futurist": { responseType: "analysis", systemPrompt: buildPersonaPrompt("Tech Futurist", "Taylor") },
  "Systems Thinker": { responseType: "analysis", systemPrompt: buildPersonaPrompt("Systems Thinker", "Avery") },
  "The Pragmatist": { responseType: "analysis", systemPrompt: buildPersonaPrompt("The Pragmatist", "Drew") },
};

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseAnonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const cronSecret = Deno.env.get("CRON_SECRET");

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    if (req.method !== "POST") {
      return new Response(JSON.stringify({ error: "Method not allowed" }), {
        status: 405,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json();

    const url = new URL(req.url);
    const pathSegments = url.pathname.split("/").filter(Boolean);
    const lastSegment = pathSegments[pathSegments.length - 1];
    const action = body.action || (lastSegment !== "ai-agents" ? lastSegment : null);

    const isServiceRole = authHeader === `Bearer ${supabaseServiceKey}`;
    const xCronSecret = req.headers.get("x-cron-secret");

    const isCronRequest = cronSecret != null && (authHeader === `Bearer ${cronSecret}` || xCronSecret === cronSecret);

    const userClient = createClient(supabaseUrl, supabaseAnonKey, {
      global: { headers: { Authorization: authHeader } },
    });

    const { data: { user }, error: authError } = await userClient.auth.getUser();
    if (authError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { data: profileData } = await supabase
      .from("profiles")
      .select("country")
      .eq("id", user.id)
      .maybeSingle();
    const userCountry: string | null = profileData?.country ?? null;

    // Actions that call OpenAI are quota-gated. save-context is a DB-only write.
    if (action !== "save-context") {
      const quotaDenied = await checkAndIncrementQuota(user.id, supabase);
      if (quotaDenied) return quotaDenied;
    }

    if (action === "generate") {
      return await handleGenerate(body, supabase, userCountry, user.id);
    }

    if (action === "chat") {
      return await handleChat(body, supabase, userCountry, user.id);
    }

    if (action === "consensus") {
      return await handleConsensus(body, supabase, user.id);
    }

    if (action === "save-context") {
      return await handleSaveUserContext(body, supabase, user.id);
    }

    if (action === "recommend") {
      return await handleRecommend(body, supabase, user.id);
    }

    if (action === "weekly-digest") {
      return await handleWeeklyDigest(body, supabase, user.id);
    }

    if (action === "resolve-assumption") {
      return await handleResolveAssumption(body, supabase, user.id);
    }

    return new Response(JSON.stringify({ error: "Missing or unknown action", action, path: url.pathname }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (err) {
    return new Response(JSON.stringify({ error: String(err) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});

async function handleResolveAssumption(body: Record<string, unknown>, supabase: ReturnType<typeof createClient>, userId: string) {
  const { assumptionId } = body as { assumptionId: string };

  if (!assumptionId) {
    return new Response(JSON.stringify({ error: "Missing assumptionId" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const { data: assumption, error: assumptionError } = await supabase
    .from("pod_assumptions")
    .select("id, content, description, pod_id, created_by, insight_type, pods(name, question_text)")
    .eq("id", assumptionId)
    .maybeSingle();

  if (assumptionError || !assumption) {
    return new Response(JSON.stringify({ error: "Assumption not found" }), {
      status: 404,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const { data: existingOutcome } = await supabase
    .from("assumption_outcomes")
    .select("id, outcome, resolved_by_ai")
    .eq("assumption_id", assumptionId)
    .maybeSingle();

  if (existingOutcome) {
    return new Response(JSON.stringify({ error: "Assumption already resolved", outcome: existingOutcome }), {
      status: 409,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const { data: existingRequest } = await supabase
    .from("ai_resolution_requests")
    .select("id, status")
    .eq("assumption_id", assumptionId)
    .maybeSingle();

  if (existingRequest?.status === "pending") {
    return new Response(JSON.stringify({ error: "AI resolution already in progress" }), {
      status: 409,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const { data: isMember } = await supabase
    .from("pod_members")
    .select("id")
    .eq("pod_id", assumption.pod_id)
    .eq("user_id", userId)
    .maybeSingle();

  if (!isMember) {
    return new Response(JSON.stringify({ error: "You must be a pod member to request AI resolution" }), {
      status: 403,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const { data: agentResponses } = await supabase
    .from("agent_responses")
    .select("content, response_type, confidence_score, ai_agents(name)")
    .eq("assumption_id", assumptionId)
    .order("confidence_score", { ascending: false })
    .limit(6);

  const { data: challenges } = await supabase
    .from("assumption_challenges")
    .select("content, created_at")
    .eq("assumption_id", assumptionId)
    .limit(5);

  const { data: forecasts } = await supabase
    .from("assumption_forecasts")
    .select("probability, rationale")
    .eq("assumption_id", assumptionId)
    .limit(10);

  const pod = assumption.pods as { name: string; question_text: string } | null;

  const agentSummary = (agentResponses || []).map((r: {
    content: string;
    response_type: string;
    confidence_score: number;
    ai_agents: { name: string } | null;
  }) => `- ${r.ai_agents?.name || "Agent"} (${r.response_type}, confidence ${r.confidence_score}%): ${r.content.slice(0, 200)}`).join("\n");

  const challengeSummary = (challenges || []).map((c: { content: string }) => `- ${c.content.slice(0, 150)}`).join("\n");

  const forecastSummary = (forecasts || []).map((f: { probability: number; rationale: string }) =>
    `- ${f.probability}% probability${f.rationale ? `: ${f.rationale.slice(0, 100)}` : ""}`
  ).join("\n");

  const avgForecast = forecasts && forecasts.length > 0
    ? Math.round((forecasts as { probability: number }[]).reduce((sum, f) => sum + f.probability, 0) / forecasts.length)
    : null;

  const insightTypeLabel = (assumption as { insight_type?: string }).insight_type || "General";
  const insightTypeDesc = INSIGHT_TYPE_DESCRIPTIONS[insightTypeLabel] || "statement or observation";

  const systemPrompt = `You are an impartial AI arbiter tasked with resolving whether a strategic ${insightTypeDesc} has been confirmed or refuted based on available evidence.

Your job is to make a definitive verdict — not to hedge. You must choose one of three outcomes:
- "confirmed": The ${insightTypeLabel.toLowerCase()} has held true based on evidence and reasoning
- "refuted": The ${insightTypeLabel.toLowerCase()} has been shown to be wrong or failed to materialise
- "still_open": There is genuinely insufficient evidence to make a call right now

Rules:
1. Be decisive. Only use "still_open" if resolution is truly impossible with current information.
2. Base your verdict on the balance of evidence from AI agent analyses, community challenges, and forecast consensus.
3. Provide a clear reasoning chain (4-6 sentences) explaining why you chose this verdict. Cite the specific evidence that drove the decision — which agent analysis, which data point, which analogue was most decisive.
4. Report a confidence score (0-100) reflecting how certain you are of the verdict.
5. Return ONLY valid JSON in this exact format: {"verdict":"confirmed"|"refuted"|"still_open","reasoning":"...","confidence":85}`;

  const userMessage = `Decision room: "${pod?.name || "Unknown"}"
Core question: "${pod?.question_text || "Unknown"}"

${insightTypeLabel} to resolve: "${assumption.content}"
${assumption.description ? `Additional context: ${assumption.description}` : ""}

AI Agent analyses:
${agentSummary || "No agent analyses available"}

Community challenges:
${challengeSummary || "No challenges raised"}

Forecast data:
${forecastSummary || "No forecasts submitted"}
${avgForecast !== null ? `Average forecast probability: ${avgForecast}%` : ""}

Based on all of the above, deliver your verdict.`;

  let verdict: "confirmed" | "refuted" | "still_open" = "still_open";
  let reasoning = "Insufficient evidence to make a definitive determination at this time.";
  let confidence = 40;

  try {
    const raw = await callOpenAI(systemPrompt, userMessage, TOKEN_LIMITS.resolution, true);
    const parsed = JSON.parse(raw);
    if (parsed.verdict && ["confirmed", "refuted", "still_open"].includes(parsed.verdict)) {
      verdict = parsed.verdict;
    }
    if (parsed.reasoning && typeof parsed.reasoning === "string") {
      reasoning = parsed.reasoning;
    }
    if (typeof parsed.confidence === "number") {
      confidence = Math.min(100, Math.max(0, Math.round(parsed.confidence)));
    }
  } catch (_e) {
    // fallback defaults already set
  }

  const systemSupabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
  );

  await systemSupabase
    .from("ai_resolution_requests")
    .upsert({
      assumption_id: assumptionId,
      requested_by: userId,
      status: "completed",
      completed_at: new Date().toISOString(),
    }, { onConflict: "assumption_id" });

  const { data: outcomeData, error: outcomeError } = await systemSupabase
    .from("assumption_outcomes")
    .insert({
      assumption_id: assumptionId,
      resolved_by: userId,
      outcome: verdict,
      evidence: reasoning,
      resolved_by_ai: true,
      ai_reasoning: reasoning,
      ai_confidence: confidence,
    })
    .select()
    .single();

  if (outcomeError) {
    await systemSupabase
      .from("ai_resolution_requests")
      .update({ status: "failed" })
      .eq("assumption_id", assumptionId);

    return new Response(JSON.stringify({ error: "Failed to save outcome" }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  return new Response(JSON.stringify({ outcome: outcomeData, verdict, reasoning, confidence }), {
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

interface ReferenceLink {
  title: string;
  url: string;
  description: string;
}

async function generateReferenceLinks(
  agentName: string,
  content: string,
  assumptionText: string,
  insightType?: string
): Promise<ReferenceLink[]> {
  const systemPrompt = `You are a research librarian. Given an AI analyst's commentary on a topic, suggest 1-2 real, credible reference links that would genuinely help someone research this further.

Rules:
- Only suggest links that are VERY LIKELY to actually exist (major publications, Wikipedia, Google Scholar, Statista, World Bank, etc.)
- Prefer well-known, stable URLs: en.wikipedia.org, statista.com, ourworldindata.org, hbr.org, mckinsey.com, weforum.org, who.int, worldbank.org, imf.org, nature.com, nytimes.com, ft.com, economist.com, forbes.com, bloomberg.com, investopedia.com, techcrunch.com, mit.edu, stanford.edu
- URLs must be plausible search or topic paths — not made-up article slugs
- For Wikipedia: use the format https://en.wikipedia.org/wiki/Topic_Name
- For search queries: use https://scholar.google.com/scholar?q=query or https://www.google.com/search?q=query
- Keep title under 60 characters
- Keep description under 80 characters

Respond ONLY with valid JSON array:
[
  { "title": "...", "url": "https://...", "description": "..." }
]`;

  const userMsg = `Agent: ${agentName}
Topic insight: "${assumptionText}"
${insightType ? `Type: ${insightType}` : ""}
Agent said: "${content.slice(0, 300)}"

Suggest 1-2 reference links.`;

  try {
    const raw = await callOpenAI(systemPrompt, userMsg, TOKEN_LIMITS.reference_links, true);
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) {
      return parsed.slice(0, 2).filter((l: ReferenceLink) => l.title && l.url && l.url.startsWith("http"));
    }
    return [];
  } catch {
    return [];
  }
}

const DAILY_AI_LIMIT = 100;

// Returns a 429 Response if the user has exceeded their daily limit, otherwise null.
async function checkAndIncrementQuota(
  userId: string,
  supabase: ReturnType<typeof createClient>,
): Promise<Response | null> {
  const today = new Date().toISOString().slice(0, 10);
  const { error: upsertErr } = await supabase.rpc("increment_daily_ai_usage", {
    p_user_id: userId,
    p_date: today,
  });

  const { data: usageRow } = await supabase
    .from("daily_ai_usage")
    .select("message_count")
    .eq("user_id", userId)
    .eq("date", today)
    .maybeSingle();

  const count = usageRow?.message_count ?? 0;

  if (shouldBlockQuota(count, DAILY_AI_LIMIT, !!upsertErr)) {
    return new Response(
      JSON.stringify({ error: "Daily AI limit reached. Please try again tomorrow.", quota_exceeded: true }),
      { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
  return null;
}

// Verifies that userId can access the assumption's pod.
// Returns a 403 Response if denied, otherwise null.
async function checkAssumptionAccess(
  assumptionId: string,
  userId: string,
  supabase: ReturnType<typeof createClient>,
): Promise<Response | null> {
  const { data: assumption } = await supabase
    .from("pod_assumptions")
    .select("pod_id, pods(is_public)")
    .eq("id", assumptionId)
    .maybeSingle();

  if (!assumption) {
    return new Response(
      JSON.stringify({ error: "Assumption not found" }),
      { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }

  const pod = assumption.pods as { is_public: boolean } | null;
  if (pod?.is_public) return null;

  const { data: membership } = await supabase
    .from("pod_members")
    .select("id")
    .eq("pod_id", assumption.pod_id)
    .eq("user_id", userId)
    .maybeSingle();

  if (!membership) {
    return new Response(
      JSON.stringify({ error: "Access denied: not a member of this pod" }),
      { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
  return null;
}

async function checkThreadAccess(
  threadId: string,
  userId: string,
  supabase: ReturnType<typeof createClient>,
): Promise<Response | null> {
  const { data: thread } = await supabase
    .from("decision_threads")
    .select("pod_id, pods(is_public)")
    .eq("id", threadId)
    .maybeSingle();

  if (!thread) return null;

  const pod = thread.pods as { is_public: boolean } | null;
  if (pod?.is_public) return null;

  const { data: membership } = await supabase
    .from("pod_members")
    .select("id")
    .eq("pod_id", thread.pod_id)
    .eq("user_id", userId)
    .maybeSingle();

  if (!membership) {
    return new Response(
      JSON.stringify({ error: "Access denied: not a member of this pod" }),
      { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } },
    );
  }
  return null;
}

const TOKEN_LIMITS: Record<string, number> = {
  challenge: 500,
  risk: 500,
  alternative: 500,
  question: 450,
  analysis: 500,
  consensus: 1600,
  resolution: 700,
  recommendation: 1400,
  next_steps: 1600,
  research_sources: 700,
  weekly_digest: 400,
  reference_links: 500,
  chat: 500,
};

interface StructuredOutput {
  idea: string;
  assumptions: string[];
  risks: string[];
  counterarguments: string[];
  confidence_score: number;
  disagreement_level: number;
  risk_level: number;
  recommended_action: string;
}

function buildStructuredOutput(
  agentName: string,
  responseType: string,
  rawContent: string,
  _assumptionText: string,
  insightType?: string
): StructuredOutput {
  const lower = rawContent.toLowerCase();

  const HIGH_CONF = ["clearly", "certainly", "definitely", "strong evidence", "data shows", "proven", "consistently", "undeniably"];
  const LOW_CONF = ["uncertain", "unclear", "may", "might", "possibly", "arguably", "difficult to say", "hard to predict", "depends"];
  const HIGH_RISK = ["risk", "danger", "threat", "failure", "collapse", "downside", "catastrophic", "severe", "critical", "warning", "crisis"];
  const CONTRARIAN = ["contrary", "wrong", "misconception", "overlooked", "underestimated", "counterintuitive", "challenge", "disagree", "actually", "in fact", "myth"];

  const count = (signals: string[]) => signals.filter(s => lower.includes(s)).length;

  const TYPE_CONFIDENCE: Record<string, number> = { analysis: 72, challenge: 68, risk: 65, alternative: 70, question: 60 };
  const TYPE_DISAGREEMENT: Record<string, number> = { challenge: 72, alternative: 65, risk: 55, question: 50, analysis: 35 };
  const TYPE_RISK: Record<string, number> = { risk: 75, challenge: 60, alternative: 50, question: 45, analysis: 35 };

  const baseConf = TYPE_CONFIDENCE[responseType] ?? 70;
  const baseDisag = TYPE_DISAGREEMENT[responseType] ?? 50;
  const baseRisk = TYPE_RISK[responseType] ?? 40;

  const confidence_score = Math.min(95, Math.max(40, baseConf + count(HIGH_CONF) * 4 - count(LOW_CONF) * 5));
  const disagreement_level = Math.min(95, Math.max(10, baseDisag + count(CONTRARIAN) * 8));
  const risk_level = Math.min(95, Math.max(10, baseRisk + count(HIGH_RISK) * 6));

  const firstSentence = rawContent.split(/[.!?]/)[0]?.trim() || rawContent.slice(0, 120);
  const idea = firstSentence.length > 15 ? firstSentence : rawContent.slice(0, 120);

  const risks: string[] = [];
  if (responseType === "risk") risks.push(rawContent.slice(0, 180));

  const counterarguments: string[] = [];
  if (responseType === "challenge" || responseType === "alternative") {
    counterarguments.push(rawContent.slice(0, 180));
  }

  const ACTION_VERBS = ["consider", "monitor", "investigate", "evaluate", "test", "validate", "review", "assess", "explore"];
  const foundVerb = ACTION_VERBS.find(v => lower.includes(v));
  const recommended_action = foundVerb
    ? rawContent.slice(lower.indexOf(foundVerb), lower.indexOf(foundVerb) + 80).trim()
    : `Evaluate the ${insightType?.toLowerCase() || "claim"} from ${agentName} before proceeding`;

  const impliedAssumptions: string[] = [];
  if (lower.includes("assum")) impliedAssumptions.push("Current trends continue as projected");
  if (lower.includes("market")) impliedAssumptions.push("Market conditions remain relatively stable");

  return {
    idea,
    assumptions: impliedAssumptions.slice(0, 2),
    risks,
    counterarguments,
    confidence_score,
    disagreement_level,
    risk_level,
    recommended_action,
  };
}

async function callOpenAI(systemPrompt: string, userMessage: string, maxTokens = 400, jsonMode = false, distinctId = "system", temperature = 0.6): Promise<string> {
  const openaiKey = Deno.env.get("OPENAI_API_KEY");
  if (!openaiKey) throw new Error("OpenAI API key not configured");

  const body: Record<string, unknown> = {
    model: "gpt-5.6-luna",
    messages: [
      { role: "system", content: systemPrompt },
      { role: "user", content: userMessage },
    ],
    max_completion_tokens: maxTokens,
  };

  if (jsonMode && body.model !== "gpt-5.6-luna") {
    body.response_format = { type: "json_object" };
  }

  const startedAt = Date.now();
  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${openaiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(body),
  });

  if (!response.ok) {
    const err = await response.text();
    phCaptureServer("ai_openai_call_failed", distinctId, {
      model: "gpt-5.6-luna",
      status: response.status,
      latency_ms: Date.now() - startedAt,
      json_mode: jsonMode,
    });
    throw new Error(`OpenAI API error (${response.status}): ${err}`);
  }

  const data = await response.json();
  phCaptureServer("ai_openai_call", distinctId, {
    model: "gpt-5.6-luna",
    prompt_tokens: data.usage?.prompt_tokens ?? null,
    completion_tokens: data.usage?.completion_tokens ?? null,
    total_tokens: data.usage?.total_tokens ?? null,
    max_completion_tokens: maxTokens,
    json_mode: jsonMode,
    latency_ms: Date.now() - startedAt,
  });
  return data.choices[0].message.content.trim();
}

const INSIGHT_TYPE_DESCRIPTIONS: Record<string, string> = {
  "General": "statement or observation",
  "Idea": "idea or proposed concept",
  "Claim": "claim believed to be true",
  "Hypothesis": "testable hypothesis",
  "Prediction": "prediction about future events",
  "Concern": "concern or risk worth discussing",
  "Opportunity": "opportunity or potential upside",
};

function buildAssumptionContext(assumptionText: string, assumptionDescription?: string, podContext?: string, insightType?: string): string {
  const typeLabel = insightType && insightType !== "General" ? insightType : "Insight";
  const typeDesc = INSIGHT_TYPE_DESCRIPTIONS[insightType || "General"] || "statement or observation";
  let context = `${typeLabel}: "${assumptionText}"\n(This is a ${typeDesc})`;
  if (assumptionDescription && assumptionDescription.trim()) {
    context += `\n\nContext & background: ${assumptionDescription}`;
  }
  if (podContext && podContext.trim()) {
    context += `\n\nDecision room topic: ${podContext}`;
  }
  return context;
}

async function handleSaveUserContext(body: Record<string, unknown>, supabase: ReturnType<typeof createClient>, userId: string) {
  const { assumptionId, expertiseLevel, statedPrior, goals, industryContext, focusAreas } = body as {
    assumptionId: string;
    expertiseLevel?: string;
    statedPrior?: number;
    goals?: string;
    industryContext?: string;
    focusAreas?: string[];
  };

  if (!assumptionId) {
    return new Response(JSON.stringify({ error: "Missing assumptionId" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const accessDenied = await checkAssumptionAccess(assumptionId, userId, supabase);
  if (accessDenied) return accessDenied;

  const { data, error } = await supabase
    .from("user_assumption_context")
    .upsert({
      user_id: userId,
      assumption_id: assumptionId,
      expertise_level: expertiseLevel || "intermediate",
      stated_prior: statedPrior ?? null,
      goals: goals || "",
      industry_context: industryContext || "",
      focus_areas: focusAreas || [],
      updated_at: new Date().toISOString(),
    }, { onConflict: "user_id,assumption_id" })
    .select()
    .single();

  if (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  return new Response(JSON.stringify({ context: data }), {
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

async function handleChat(body: Record<string, unknown>, supabase: ReturnType<typeof createClient>, userCountry?: string | null, userId?: string) {
  const { agentId, agentName, userMessage, assumptionId, assumptionContext, assumptionDescription, podContext, insightType, conversationHistory } = body as {
    agentId?: string;
    agentName: string;
    userMessage: string;
    assumptionId?: string;
    assumptionContext?: string;
    assumptionDescription?: string;
    podContext?: string;
    insightType?: string;
    conversationHistory?: { user: string; agent: string }[];
  };

  if (!agentName || !userMessage) {
    return new Response(JSON.stringify({ error: "Missing agentName or userMessage" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  if (userId && assumptionId) {
    const denied = await checkAssumptionAccess(assumptionId, userId, supabase);
    if (denied) return denied;
  }

  const persona = getPersonaForAgent(agentName, userCountry);
  if (!persona) {
    return new Response(JSON.stringify({ error: "Unknown agent" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  let dbHistory: { role: string; content: string; turn_index: number }[] = [];
  if (userId && assumptionId && agentId) {
    const { data: memRows } = await supabase
      .from("agent_conversation_memory")
      .select("role, content, turn_index")
      .eq("user_id", userId)
      .eq("assumption_id", assumptionId)
      .eq("agent_id", agentId)
      .order("turn_index", { ascending: false })
      .limit(10);
    if (memRows && memRows.length > 0) {
      dbHistory = [...memRows].reverse();
    }
  }

  let userContext: { expertise_level: string; stated_prior: number | null; goals: string; industry_context: string } | null = null;
  if (userId && assumptionId) {
    const { data: ctx } = await supabase
      .from("user_assumption_context")
      .select("expertise_level, stated_prior, goals, industry_context")
      .eq("user_id", userId)
      .eq("assumption_id", assumptionId)
      .maybeSingle();
    userContext = ctx;
  }

  const fullContext = assumptionContext
    ? buildAssumptionContext(assumptionContext, assumptionDescription, podContext, insightType)
    : "";

  const contextBlock = fullContext ? `\n\n${fullContext}\n` : "";

  const userCtxBlock = userContext
    ? `\n\nUser context: expertise=${userContext.expertise_level}${userContext.stated_prior != null ? `, prior belief=${userContext.stated_prior}%` : ""}${userContext.goals ? `, goals: ${userContext.goals}` : ""}${userContext.industry_context ? `, industry: ${userContext.industry_context}` : ""}\n`
    : "";

  const memorySource = dbHistory.length > 0 ? dbHistory : (conversationHistory || []).map((h, i) => [
    { role: "user", content: h.user, turn_index: i * 2 },
    { role: "agent", content: h.agent, turn_index: i * 2 + 1 },
  ]).flat();

  const historyBlock = memorySource.length > 0
    ? "\n\nConversation so far:\n" + memorySource.map((h) =>
        `${h.role === "user" ? "User" : "You"}: ${h.content}`
      ).join("\n\n") + "\n"
    : "";

  const systemPrompt = `${persona.systemPrompt}${contextBlock}${userCtxBlock}${historyBlock}

You're now responding to a follow-up question. Stay in character. Engage directly with what they said — address their specific point, don't generalize. Apply the same analytical rigour as your initial analysis: cite mechanisms, name evidence, quantify where possible. Tailor depth to the user's expertise level if known. If they raise a valid challenge to your earlier position, acknowledge it honestly and update your reasoning. Intellectual honesty is mandatory.`;

  const reply = await callOpenAI(systemPrompt, userMessage as string, TOKEN_LIMITS.chat);
  const confidence = Math.floor(Math.random() * 15) + 75;

  if (userId && assumptionId && agentId) {
    const { data: lastTurn } = await supabase
      .from("agent_conversation_memory")
      .select("turn_index")
      .eq("user_id", userId)
      .eq("assumption_id", assumptionId)
      .eq("agent_id", agentId)
      .order("turn_index", { ascending: false })
      .limit(1)
      .maybeSingle();

    const nextIndex = (lastTurn?.turn_index ?? -1) + 1;

    await supabase.from("agent_conversation_memory").insert([
      { user_id: userId, assumption_id: assumptionId, agent_id: agentId, role: "user", content: userMessage, turn_index: nextIndex },
      { user_id: userId, assumption_id: assumptionId, agent_id: agentId, role: "agent", content: reply, turn_index: nextIndex + 1 },
    ]);
  }

  return new Response(JSON.stringify({ reply, confidence }), {
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

async function handleGenerate(body: Record<string, unknown>, supabase: ReturnType<typeof createClient>, userCountry?: string | null, userId?: string) {
  const { assumptionId, assumptionText, assumptionDescription, podContext, outcomeContext, insightType } = body as {
    assumptionId: string;
    assumptionText: string;
    assumptionDescription?: string;
    podContext?: string;
    outcomeContext?: string;
    insightType?: string;
  };

  if (!assumptionId || !assumptionText) {
    return new Response(JSON.stringify({ error: "Missing assumptionId or assumptionText" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  if (userId) {
    const denied = await checkAssumptionAccess(assumptionId, userId, supabase);
    if (denied) return denied;
  }

  const { data: agents } = await supabase
    .from("ai_agents")
    .select("id, name")
    .eq("is_active", true)
    .order("name");

  if (!agents || agents.length === 0) {
    return new Response(JSON.stringify({ error: "No active agents found" }), {
      status: 404,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const { data: existingResponses } = await supabase
    .from("agent_responses")
    .select("agent_id")
    .eq("assumption_id", assumptionId);

  const agentsWithResponse = new Set((existingResponses || []).map((r: { agent_id: string }) => r.agent_id));
  const eligibleAgents = agents.filter((a: { id: string; name: string }) => !agentsWithResponse.has(a.id));

  if (eligibleAgents.length === 0) {
    return new Response(JSON.stringify({ responses: [], alreadyRan: true }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // Fetch user-specific context to personalise agent prompts
  let userContext: { expertise_level: string; stated_prior: number | null; goals: string; industry_context: string } | null = null;
  if (userId) {
    const { data: ctx } = await supabase
      .from("user_assumption_context")
      .select("expertise_level, stated_prior, goals, industry_context")
      .eq("user_id", userId)
      .eq("assumption_id", assumptionId)
      .maybeSingle();
    userContext = ctx;
  }

  const topic = classifyTopic(assumptionText, podContext);
  const shuffled = selectContextualAgents(eligibleAgents, topic, 3);

  const fullContext = buildAssumptionContext(assumptionText, assumptionDescription, podContext, insightType);
  const outcomeBlock = outcomeContext ? `\n\nIMPORTANT CONTEXT: ${outcomeContext}` : "";

  const userCtxBlock = userContext
    ? `\n\nUser context: expertise=${userContext.expertise_level}${userContext.stated_prior != null ? `, prior belief=${userContext.stated_prior}%` : ""}${userContext.goals ? `, goals: ${userContext.goals}` : ""}${userContext.industry_context ? `, industry: ${userContext.industry_context}` : ""}`
    : "";

  const results = await Promise.allSettled(
    shuffled.map(async (agent: { id: string; name: string }) => {
      const persona = getPersonaForAgent(agent.name, userCountry);
      if (!persona) return null;

      const typeLabel = insightType && insightType !== "General" ? insightType.toLowerCase() : "insight";
      const responseTokenLimit = TOKEN_LIMITS[persona.responseType] ?? TOKEN_LIMITS.analysis;

      const content = await callOpenAI(
        persona.systemPrompt,
        `Here's what you're looking at:\n\n${fullContext}${outcomeBlock}${userCtxBlock}\n\nThis is a ${typeLabel} — respond accordingly. What's your honest take?`,
        responseTokenLimit
      );

      const structured = buildStructuredOutput(agent.name, persona.responseType, content, assumptionText, insightType);
      const confidence = structured.confidence_score;

      const referenceLinks = await generateReferenceLinks(
        agent.name,
        content,
        assumptionText,
        insightType
      );

      const { data, error } = await supabase
        .from("agent_responses")
        .insert({
          agent_id: agent.id,
          assumption_id: assumptionId,
          response_type: persona.responseType,
          content,
          confidence_score: confidence,
          display_name: persona.displayName,
          reference_links: referenceLinks.length > 0 ? referenceLinks : null,
          structured_output: structured,
          disagreement_level: structured.disagreement_level,
          risk_level: structured.risk_level,
        })
        .select()
        .single();

      if (error) throw error;

      await Promise.all([
        createStructuredContent(supabase, agent.id, assumptionId, persona.responseType, content, confidence),
        supabase.from("agent_decision_memory").upsert({
          assumption_id: assumptionId,
          agent_id: agent.id,
          idea: structured.idea,
          assumptions: structured.assumptions,
          risks: structured.risks,
          counterarguments: structured.counterarguments,
          confidence_score: confidence,
          disagreement_level: structured.disagreement_level,
          risk_level: structured.risk_level,
          recommended_action: structured.recommended_action,
          response_type: persona.responseType,
          pod_context: podContext ?? null,
          insight_type: insightType ?? null,
        }, { onConflict: "assumption_id,agent_id" }),
        supabase.from("agent_response_scores").upsert({
          agent_response_id: data.id,
          assumption_id: assumptionId,
          agent_id: agent.id,
          confidence_score: confidence,
          disagreement_level: structured.disagreement_level,
          risk_level: structured.risk_level,
        }, { onConflict: "agent_response_id" }),
      ]);

      return { data, structured };
    })
  );

  const successful = results
    .filter((r) => r.status === "fulfilled" && r.value !== null)
    .map((r) => (r as PromiseFulfilledResult<{ data: Record<string, unknown>; structured: StructuredOutput }>).value);

  // Record this as a decision run for history tracking
  if (userId && successful.length > 0) {
    const scores = successful.map((s) => s.structured);
    const avgConfidence = Math.round(scores.reduce((sum, s) => sum + s.confidence_score, 0) / scores.length);
    const avgDisagreement = Math.round(scores.reduce((sum, s) => sum + s.disagreement_level, 0) / scores.length);
    const avgRisk = Math.round(scores.reduce((sum, s) => sum + s.risk_level, 0) / scores.length);

    await supabase.from("agent_decision_runs").insert({
      assumption_id: assumptionId,
      user_id: userId,
      agents_used: shuffled.map((a: { name: string }) => a.name),
      composite_confidence: avgConfidence,
      composite_disagreement: avgDisagreement,
      composite_risk: avgRisk,
      agent_count: successful.length,
      triggered_by: "user",
      run_metadata: { topic, insightType: insightType ?? null },
    });
  }

  return new Response(JSON.stringify({ responses: successful.map((s) => s.data) }), {
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

async function handleConsensus(body: Record<string, unknown>, supabase: ReturnType<typeof createClient>, userId?: string) {
  const { assumptionId, assumptionText, assumptionDescription, podContext, forceRegenerate, outcomeContext, insightType } = body as {
    assumptionId: string;
    assumptionText: string;
    assumptionDescription?: string;
    podContext?: string;
    forceRegenerate?: boolean;
    outcomeContext?: string;
    insightType?: string;
  };

  if (!assumptionId || !assumptionText) {
    return new Response(JSON.stringify({ error: "Missing assumptionId or assumptionText" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  if (userId) {
    const denied = await checkAssumptionAccess(assumptionId, userId, supabase);
    if (denied) return denied;
  }

  if (!forceRegenerate) {
    const { data: existing } = await supabase
      .from("agent_consensus")
      .select("*")
      .eq("assumption_id", assumptionId)
      .maybeSingle();

    if (existing) {
      return new Response(JSON.stringify({ consensus: existing, cached: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
  }

  const { data: agentResponses } = await supabase
    .from("agent_responses")
    .select("response_type, content, confidence_score, ai_agents(name, role)")
    .eq("assumption_id", assumptionId)
    .order("created_at", { ascending: true });

  if (!agentResponses || agentResponses.length === 0) {
    return new Response(JSON.stringify({ error: "No agent responses found. Run analysis first." }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const fullContext = buildAssumptionContext(assumptionText, assumptionDescription, podContext, insightType);

  const agentSummary = agentResponses.map((r: {
    response_type: string;
    content: string;
    confidence_score: number;
    ai_agents: { name: string; role: string } | null;
  }) => {
    const name = r.ai_agents?.name || "Someone";
    const role = r.ai_agents?.role || r.response_type;
    return `${name} (${role}) said:\n"${r.content}"`;
  }).join("\n\n");

  const consensusSystemPrompt = `You are synthesizing the output of a panel of AI analysts who have each given their honest take on an assumption. Your job is to map the intellectual landscape of the discussion — not just summarize it.

Your output must capture:

1. VERDICT — the clearest overall signal from the group:
   - "likely_valid" — most people think this holds up and the logic is sound
   - "likely_invalid" — most people have serious, substantive doubts
   - "mixed" — real points on both sides, genuinely unclear
   - "insufficient_data" — the group agrees more evidence is needed

2. CONFIDENCE SCORE — 0 to 100. This must reflect the actual level of agreement and evidence quality in the responses above. Use this rubric:
   - 85-100: Near-unanimous agreement, strong evidence cited (specific data, real-world analogues, quantified claims), very little dissent
   - 70-84: Clear majority view, minor caveats, mostly aligned reasoning with adequate evidence
   - 50-69: Genuine split with substantive arguments on both sides, mixed evidence quality
   - 30-49: More disagreement than agreement, significant uncertainty, weak evidence on all sides
   - 0-29: Near-total disagreement or almost no usable evidence
   Do NOT default to 65. Calculate based on how many agents actually agreed, how strong their evidence was (specificity of data, quality of analogues, quantification), and how many analytical frameworks were applied vs surface-level opinion.

3. SUMMARY — 3-4 sentences. Plain English. What was the overall mood? What was the core tension? What was the strongest piece of evidence cited by either side?

4. AGREEMENT AREAS — what did the analysts broadly agree on? (even if they disagreed on the conclusion). 2-4 items. Short, clear sentences.

5. POSITIONS — this is the most important part. Identify 2 (or 3 if clearly distinct) named positions the analysts split into. For each position:
   - "label": a short, descriptive name for this viewpoint (e.g. "AI Disrupts Consulting", "Human Edge Remains")
   - "stance": "majority" if more than half hold this view, "minority" if fewer, "split" if roughly equal
   - "agents": array of agent role names (e.g. ["Market Analyst", "The Skeptic"]) who hold this view
   - "view": one sentence — what do they actually believe?
   - "reasoning": one sentence — what is their core reason for believing it?

If there is genuine consensus (all agents agree), you may return only 1 position with stance "majority" and note it in the summary.

Respond ONLY with valid JSON in this exact format — no text outside the JSON:
{
  "verdict": "likely_valid" | "likely_invalid" | "mixed" | "insufficient_data",
  "confidence_score": <number 0-100>,
  "summary": "<2-3 sentence plain-English summary>",
  "agreement_areas": ["<thing they agreed on>", ...],
  "key_points": ["<specific, actionable point>", ...],
  "positions": [
    {
      "label": "<position name>",
      "stance": "majority" | "minority" | "split",
      "agents": ["<agent role>", ...],
      "view": "<one sentence — what they believe>",
      "reasoning": "<one sentence — why>"
    }
  ]
}`;

  const outcomeBlock = outcomeContext ? `\n\nIMPORTANT CONTEXT: ${outcomeContext}` : "";

  const userMessage = `${fullContext}${outcomeBlock}

Here's what each analyst said:

${agentSummary}

Now produce the structured analysis.`;

  const rawResponse = await callOpenAI(consensusSystemPrompt, userMessage, TOKEN_LIMITS.consensus, true);

  let parsed: {
    verdict: string;
    confidence_score: number;
    summary: string;
    key_points: string[];
    agreement_areas: string[];
    positions: {
      label: string;
      stance: string;
      agents: string[];
      view: string;
      reasoning: string;
    }[];
  };

  try {
    const jsonMatch = rawResponse.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error("No JSON found in response");
    parsed = JSON.parse(jsonMatch[0]);
  } catch (_e) {
    parsed = {
      verdict: "mixed",
      confidence_score: 55,
      summary: rawResponse,
      key_points: [],
      agreement_areas: [],
      positions: [],
    };
  }

  const validVerdicts = ["likely_valid", "likely_invalid", "mixed", "insufficient_data"];
  if (!validVerdicts.includes(parsed.verdict)) parsed.verdict = "mixed";
  if (parsed.confidence_score < 0 || parsed.confidence_score > 100) parsed.confidence_score = 55;
  if (!Array.isArray(parsed.agreement_areas)) parsed.agreement_areas = [];
  if (!Array.isArray(parsed.positions)) parsed.positions = [];

  await supabase
    .from("agent_consensus")
    .delete()
    .eq("assumption_id", assumptionId);

  const { data: consensus, error: insertError } = await supabase
    .from("agent_consensus")
    .insert({
      assumption_id: assumptionId,
      verdict: parsed.verdict,
      confidence_score: parsed.confidence_score,
      summary: parsed.summary,
      key_points: parsed.key_points,
      agreement_areas: parsed.agreement_areas,
      positions: parsed.positions,
      agent_count: agentResponses.length,
    })
    .select()
    .single();

  if (insertError) throw insertError;

  // Write a prediction score record linking this consensus to a decision run
  if (userId) {
    const { data: latestRun } = await supabase
      .from("agent_decision_runs")
      .select("id, composite_confidence, composite_disagreement, composite_risk")
      .eq("assumption_id", assumptionId)
      .eq("user_id", userId)
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (latestRun) {
      await supabase.from("assumption_prediction_scores").upsert({
        assumption_id: assumptionId,
        user_id: userId,
        decision_run_id: latestRun.id,
        predicted_verdict: parsed.verdict,
        predicted_confidence: latestRun.composite_confidence ?? parsed.confidence_score,
        predicted_disagreement: latestRun.composite_disagreement ?? null,
        predicted_risk: latestRun.composite_risk ?? null,
      }, { onConflict: "assumption_id,decision_run_id" });
    }
  }

  return new Response(JSON.stringify({ consensus, cached: false }), {
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

async function handleRecommend(body: Record<string, unknown>, supabase: ReturnType<typeof createClient>, userId: string) {
  const { threadId, forceRegenerate } = body as {
    threadId: string;
    forceRegenerate?: boolean;
  };

  if (!threadId) {
    return new Response(JSON.stringify({ error: "Missing threadId" }), {
      status: 400,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const accessDenied = await checkThreadAccess(threadId, userId, supabase);
  if (accessDenied) return accessDenied;

  if (!forceRegenerate) {
    const { data: existing } = await supabase
      .from("ai_thread_recommendations")
      .select("*")
      .eq("thread_id", threadId)
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (existing) {
      return new Response(JSON.stringify({ recommendation: existing, cached: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
  }

  const { data: thread } = await supabase
    .from("decision_threads")
    .select("id, title, description, stage, success_criteria, pods(name)")
    .eq("id", threadId)
    .maybeSingle();

  if (!thread) {
    return new Response(JSON.stringify({ error: "Thread not found" }), {
      status: 404,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const { data: paths } = await supabase
    .from("decision_paths")
    .select("id, title, focus, risk_level, upside, notes, is_recommended")
    .eq("thread_id", threadId)
    .order("sort_order", { ascending: true });

  const { data: updates } = await supabase
    .from("decision_thread_updates")
    .select("update_type, content")
    .eq("thread_id", threadId)
    .order("created_at", { ascending: true });

  const podName = (thread.pods as { name?: string } | null)?.name || "Unknown";

  let contextBlock = `Decision: "${thread.title}"`;
  if (thread.description) contextBlock += `\nBackground: ${thread.description}`;
  if (thread.success_criteria) contextBlock += `\nSuccess criteria: ${thread.success_criteria}`;
  contextBlock += `\nDecision room: ${podName}`;
  contextBlock += `\nCurrent stage: ${thread.stage}`;

  let pathsBlock = "";
  if (paths && paths.length > 0) {
    pathsBlock = "\n\nDecision paths being considered:\n" + paths.map((p: {
      id: string;
      title: string;
      focus: string;
      risk_level: string;
      upside: string;
      notes: string | null;
      is_recommended: boolean;
    }, i: number) => {
      let s = `Option ${i + 1}: ${p.title}\n  Focus: ${p.focus}\n  Risk: ${p.risk_level}\n  Upside: ${p.upside}`;
      if (p.notes) s += `\n  Notes: ${p.notes}`;
      return s;
    }).join("\n\n");
  }

  const assumptions = (updates || []).filter((u: { update_type: string }) => u.update_type === "assumption_added");
  const risks = (updates || []).filter((u: { update_type: string }) => u.update_type === "risk_added");
  const scenarios = (updates || []).filter((u: { update_type: string }) => u.update_type === "scenario_added");

  let insightsBlock = "";
  if (assumptions.length > 0) {
    insightsBlock += "\nAssumptions the team identified:\n" + assumptions.map((u: { content: string }) => `- ${u.content}`).join("\n");
  }
  if (risks.length > 0) {
    insightsBlock += "\n\nRisks the team flagged:\n" + risks.map((u: { content: string }) => `- ${u.content}`).join("\n");
  }
  if (scenarios.length > 0) {
    insightsBlock += "\n\nScenarios the team considered:\n" + scenarios.map((u: { content: string }) => `- ${u.content}`).join("\n");
  }

  const totalInsights = assumptions.length + risks.length + scenarios.length;
  const hasPaths = paths && paths.length > 0;

  const systemPrompt = `You are a senior strategic advisor helping a team think through an important decision.

You have the decision context, any options on the table, and the team's accumulated insights (assumptions, risks, scenarios). Your job is to:
1. Make a clear recommendation — pick a direction or the strongest option if paths exist. Don't hedge with "it depends".
2. Give a concise, specific rationale grounded in the evidence provided.
3. Surface the key factors that matter most.
4. Flag the risks to watch if this direction is taken.
5. Provide 3-4 concrete next steps the team should take RIGHT NOW to move this decision forward.

Next steps should be practical and specific — things like "Interview 5 customers about X", "Run a 2-week pilot of Y", "Map out the cost of Z option", not vague advice like "do more research".

${hasPaths ? "" : "Since no formal decision paths have been defined yet, base your recommendation on the thread context and insights provided. Recommend the clearest direction and suggest what paths the team should explore."}

Respond ONLY with valid JSON in this exact format — no text outside the JSON:
{
  "recommended_option_number": <1-based integer if paths exist, or 0 if no paths>,
  "recommended_path_title": "<short title for the recommended direction — use the path title if paths exist, or coin a clear direction name if not>",
  "reasoning": "<3-4 sentences explaining why this is the best path, referencing the specific context and trade-offs>",
  "key_factors": ["<factor that drove this decision>", "<another factor>"],
  "risks_to_watch": ["<specific risk to monitor>", "<another risk>"],
  "next_steps": ["<concrete action to take now>", "<another action>", "<another action>"],
  "confidence_score": <50-95>
}`;

  const userMessage = `${contextBlock}${pathsBlock}
${insightsBlock}

Based on everything above, what should the team do and what are the next steps?`;

  const rawResponse = await callOpenAI(systemPrompt, userMessage, TOKEN_LIMITS.recommendation, true);

  let parsed: {
    recommended_option_number: number;
    recommended_path_title: string;
    reasoning: string;
    key_factors: string[];
    risks_to_watch: string[];
    next_steps: string[];
    confidence_score: number;
  };

  try {
    const jsonMatch = rawResponse.match(/\{[\s\S]*\}/);
    if (!jsonMatch) throw new Error("No JSON found");
    parsed = JSON.parse(jsonMatch[0]);
  } catch (_e) {
    parsed = {
      recommended_option_number: 0,
      recommended_path_title: "Further analysis needed",
      reasoning: rawResponse,
      key_factors: [],
      risks_to_watch: [],
      next_steps: [],
      confidence_score: 65,
    };
  }

  let chosenPathId: string | null = null;
  let chosenPathTitle = parsed.recommended_path_title || "Recommended direction";

  if (hasPaths && parsed.recommended_option_number > 0) {
    const optIdx = Math.max(0, Math.min(parsed.recommended_option_number - 1, paths!.length - 1));
    const chosenPath = paths![optIdx] as { id: string; title: string };
    chosenPathId = chosenPath.id;
    chosenPathTitle = chosenPath.title;
  }

  if (!Array.isArray(parsed.key_factors)) parsed.key_factors = [];
  if (!Array.isArray(parsed.risks_to_watch)) parsed.risks_to_watch = [];
  if (!Array.isArray(parsed.next_steps)) parsed.next_steps = [];
  if (parsed.confidence_score < 0 || parsed.confidence_score > 100) parsed.confidence_score = 70;

  await supabase
    .from("ai_thread_recommendations")
    .delete()
    .eq("thread_id", threadId);

  const { data: recommendation, error: insertError } = await supabase
    .from("ai_thread_recommendations")
    .insert({
      thread_id: threadId,
      recommended_path_id: chosenPathId,
      recommended_path_title: chosenPathTitle,
      reasoning: parsed.reasoning,
      key_factors: parsed.key_factors,
      risks_to_watch: parsed.risks_to_watch,
      next_steps: parsed.next_steps,
      confidence_score: parsed.confidence_score,
      agent_count: totalInsights,
      created_by: userId,
    })
    .select()
    .single();

  if (insertError) throw insertError;

  return new Response(JSON.stringify({ recommendation, cached: false }), {
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}

async function createStructuredContent(
  supabase: ReturnType<typeof createClient>,
  agentId: string,
  assumptionId: string,
  responseType: string,
  content: string,
  confidence: number
) {
  try {
    if (responseType === "challenge") {
      const existing = await supabase
        .from("assumption_challenges")
        .select("id")
        .eq("assumption_id", assumptionId)
        .eq("user_id", agentId)
        .maybeSingle();
      if (!existing.data) {
        await supabase.from("assumption_challenges").insert({
          assumption_id: assumptionId,
          user_id: agentId,
          content,
        });
      }
    } else if (responseType === "risk") {
      const existing = await supabase
        .from("assumption_risks")
        .select("id")
        .eq("assumption_id", assumptionId)
        .eq("created_by", agentId)
        .maybeSingle();
      if (!existing.data) {
        const severity = Math.min(5, Math.max(1, Math.round((100 - confidence) / 15) + 1));
        await supabase.from("assumption_risks").insert({
          assumption_id: assumptionId,
          created_by: agentId,
          description: content,
          severity,
        });
      }
    } else if (responseType === "alternative") {
      const existing = await supabase
        .from("assumption_scenarios")
        .select("id")
        .eq("assumption_id", assumptionId)
        .eq("created_by", agentId)
        .maybeSingle();
      if (!existing.data) {
        await supabase.from("assumption_scenarios").insert({
          assumption_id: assumptionId,
          created_by: agentId,
          description: content,
        });
      }
    } else if (responseType === "question" || responseType === "analysis") {
      const existing = await supabase
        .from("assumption_forecasts")
        .select("id")
        .eq("assumption_id", assumptionId)
        .eq("user_id", agentId)
        .maybeSingle();
      if (!existing.data) {
        await supabase.from("assumption_forecasts").insert({
          assumption_id: assumptionId,
          user_id: agentId,
          probability: confidence,
          justification: content,
        });
      }
    }
  } catch (_err) {
  }
}

async function handleWeeklyDigest(body: Record<string, unknown>, supabase: ReturnType<typeof createClient>, userId: string) {
  const { forceRegenerate } = body as { forceRegenerate?: boolean };

  const now = new Date();
  const weekStart = new Date(now);
  weekStart.setDate(now.getDate() - now.getDay());
  weekStart.setHours(0, 0, 0, 0);
  const weekStartStr = weekStart.toISOString().split("T")[0];

  if (!forceRegenerate) {
    const { data: existing } = await supabase
      .from("weekly_digests")
      .select("*")
      .eq("user_id", userId)
      .eq("week_start", weekStartStr)
      .maybeSingle();

    if (existing) {
      return new Response(JSON.stringify({ digest: existing, cached: true }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }
  }

  const sevenDaysAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000).toISOString();

  const { data: userPods } = await supabase
    .from("pod_members")
    .select("pod_id, pods(id, name, question_text)")
    .eq("user_id", userId);

  const podIds = (userPods || []).map((pm: { pod_id: string }) => pm.pod_id);
  const podMap: Record<string, string> = {};
  (userPods || []).forEach((pm: { pod_id: string; pods: { id: string; name: string; question_text: string } | null }) => {
    if (pm.pods) podMap[pm.pod_id] = pm.pods.name;
  });

  const { data: recentAssumptions } = await supabase
    .from("pod_assumptions")
    .select("id, content, challenge_count, created_at, pod_id, profiles:created_by(full_name, first_name, last_name, username)")
    .in("pod_id", podIds.length > 0 ? podIds : ["00000000-0000-0000-0000-000000000000"])
    .gte("created_at", sevenDaysAgo)
    .order("challenge_count", { ascending: false })
    .limit(20);

  const { data: userAssumptions } = await supabase
    .from("pod_assumptions")
    .select("id, content, challenge_count, created_at, pod_id")
    .eq("created_by", userId)
    .gte("created_at", sevenDaysAgo)
    .order("challenge_count", { ascending: false })
    .limit(10);

  const { data: agentResponses } = await supabase
    .from("agent_responses")
    .select("content, response_type, confidence_score, created_at, ai_agents(name), pod_assumptions(content, pod_id)")
    .in("assumption_id",
      (recentAssumptions || []).slice(0, 10).map((a: { id: string }) => a.id)
    )
    .order("confidence_score", { ascending: false })
    .limit(15);

  const topAssumptions = (recentAssumptions || []).slice(0, 5).map((a: {
    id: string;
    content: string;
    challenge_count: number;
    pod_id: string;
  }) => ({
    id: a.id,
    content: a.content,
    challenge_count: a.challenge_count,
    pod_name: podMap[a.pod_id] || "Unknown pod",
  }));

  const aiHighlights = (agentResponses || []).slice(0, 4).map((r: {
    content: string;
    response_type: string;
    confidence_score: number;
    ai_agents: { name: string } | null;
    pod_assumptions: { content: string; pod_id: string } | null;
  }) => ({
    agent_name: r.ai_agents?.name || "AI Agent",
    response_type: r.response_type,
    snippet: r.content.slice(0, 120) + (r.content.length > 120 ? "..." : ""),
    confidence_score: r.confidence_score,
    assumption_snippet: r.pod_assumptions?.content?.slice(0, 80) || "",
    pod_name: r.pod_assumptions?.pod_id ? (podMap[r.pod_assumptions.pod_id] || "") : "",
  }));

  const podChanges = (userPods || []).slice(0, 5).map((pm: {
    pod_id: string;
    pods: { id: string; name: string; question_text: string } | null;
  }) => {
    const podAssumptions = (recentAssumptions || []).filter((a: { pod_id: string }) => a.pod_id === pm.pod_id);
    return {
      pod_name: pm.pods?.name || "Unknown",
      pod_id: pm.pod_id,
      new_assumptions: podAssumptions.length,
      question: pm.pods?.question_text || "",
    };
  }).filter((pc: { new_assumptions: number }) => pc.new_assumptions > 0);

  const assumptionCount = (recentAssumptions || []).length;
  const podCount = podChanges.length;
  const topAgentName = aiHighlights[0]?.agent_name || "The Skeptic";
  const topAssumptionSnippet = topAssumptions[0]?.content?.slice(0, 60) || "";

  const digestSystemPrompt = `You are writing a short, punchy weekly digest for someone using a strategic decision-making platform. Keep it warm, direct, and useful. No corporate speak. 3 sentences max.

Mention: how many insights came through, any active decisions, and one specific observation that would actually be useful to them.`;

  const digestUserMessage = `This week:
- ${assumptionCount} new insights posted across ${podCount} active decisions
- Top AI responder this week: ${topAgentName}
- Most discussed insight: "${topAssumptionSnippet}"
- User's own insights this week: ${(userAssumptions || []).length}

Write their weekly summary.`;

  let summaryText = "";
  try {
    summaryText = await callOpenAI(digestSystemPrompt, digestUserMessage, TOKEN_LIMITS.weekly_digest);
  } catch (_e) {
    summaryText = `You had an active week. ${assumptionCount} new insights came through across ${podCount} decisions you're part of, with ${aiHighlights.length} notable AI insights surfaced. Check what's been challenged — that's where the most useful thinking lives.`;
  }

  await supabase
    .from("weekly_digests")
    .delete()
    .eq("user_id", userId)
    .eq("week_start", weekStartStr);

  const { data: digest, error: insertError } = await supabase
    .from("weekly_digests")
    .insert({
      user_id: userId,
      top_assumptions: topAssumptions,
      ai_highlights: aiHighlights,
      pod_changes: podChanges,
      summary_text: summaryText,
      week_start: weekStartStr,
    })
    .select()
    .single();

  if (insertError) throw insertError;

  return new Response(JSON.stringify({ digest, cached: false }), {
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
