import { useEffect } from 'react';
import { updatePageSEO } from '../lib/seo';
import { TeamSection } from './GuestHome';
import PoddleMark from '../components/PoddleMark';

interface TeamPageProps {
  onNavigate: (page: string) => void;
}

export default function Team({ onNavigate }: TeamPageProps) {
  useEffect(() => {
    updatePageSEO('team', {
      title: 'Team — Poddle AI',
      description: 'The minds behind Poddle AI, shaping decision intelligence for teams.',
      canonical: '/team',
    });
  }, []);

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 pt-10 pb-6">
        <button
          onClick={() => onNavigate('home')}
          className="flex items-center gap-2 text-sm font-semibold text-slate-500 hover:text-slate-700 transition-colors"
        >
          <PoddleMark size={22} />
          <span className="font-semibold"><span style={{ color: 'var(--signal)', fontWeight: 700 }}>Poddle</span><span style={{ color: 'var(--app-text-muted)', fontWeight: 400, marginLeft: '0.15em' }}>AI</span></span>
        </button>
      </div>
      <TeamSection />
      <footer style={{ background: 'var(--app-surface-raised)', borderTop: '1px solid var(--app-border)' }} className="py-12">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <PoddleMark size={28} />
              <span className="font-black text-lg tracking-tight">
                <span style={{ color: 'var(--signal)', fontWeight: 700 }}>Poddle</span><span style={{ color: 'var(--app-text-muted)', fontWeight: 400, marginLeft: '0.15em' }}>AI</span>
              </span>
            </div>
            <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-xs" style={{ color: 'var(--app-text-secondary)' }}>
              <button onClick={() => onNavigate('home')} className="hover:opacity-70 transition-opacity">Home</button>
              <button onClick={() => onNavigate('blog')} className="hover:opacity-70 transition-opacity">Blog</button>
              <a href="#privacy" className="hover:opacity-70 transition-opacity">Privacy</a>
              <a href="#terms" className="hover:opacity-70 transition-opacity">Terms</a>
              <a href="#contact-us" className="hover:opacity-70 transition-opacity">Contact</a>
            </div>
          </div>
          <div className="mt-8 pt-8 text-center text-xs" style={{ color: 'var(--app-text-muted)', borderTop: '1px solid var(--app-border)' }}>
            &copy; 2026 Poddle, Inc. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}
