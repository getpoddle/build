import { useState, useEffect, useCallback, useRef } from 'react';
import {
  Lock, Settings, ArrowLeft,
  MessageSquare, Activity, RefreshCw, Loader2, AlertTriangle, Clock, Users
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { useWorkspaceAccess, workspaceMetadataQuery } from '../hooks/useWorkspaceAccess';
import { useQuery } from '@tanstack/react-query';
import { useBetaAccess } from '../hooks/useBetaAccess';
import WorkspaceChat from '../components/WorkspaceChat';
import WorkspaceWarRoom, { WarRoomLockedState } from '../components/WorkspaceWarRoom';
import TeamChat from '../components/TeamChat';
import UpgradePrompt from '../components/UpgradePrompt';
import { PageErrorBoundary } from '../components/ErrorBoundary';
import { logTabChange, type TabValue } from '../lib/tabDiagnostics';
import { debugLog } from '../lib/debugLog';

type MainTab = 'chat' | 'warroom' | 'team';

interface Workspace {
  id: string;
  name: string;
  description: string;
  domain: string;
  plan: string;
  subscription_status: string;
  owner_id: string;
}

interface WorkspaceHubProps {
  workspaceId: string;
  initialTab?: string;
  onBack: () => void;
  onSettings: () => void;
  onNavigate: (page: string, id?: string) => void;
  onEntityClick?: (id: string, type: string) => void;
}

export default function WorkspaceHub({ workspaceId, initialTab, onBack, onSettings, onNavigate }: WorkspaceHubProps) {
  const { user, session } = useAuth();
  const { canAccess, isAdmin, isReadOnly, plan, subscriptionStatus, trialExpiresAt, loading: accessLoading, error: accessError } = useWorkspaceAccess(workspaceId);
  const { hasBetaAccess } = useBetaAccess();
  const workspaceIsPro = hasBetaAccess || (
    (plan === 'pro' || plan === 'team' || plan === 'business' || plan === 'enterprise') &&
    (subscriptionStatus === 'active' || subscriptionStatus === 'trialing')
  );

  const daysLeft = trialExpiresAt
    ? Math.max(0, Math.ceil((new Date(trialExpiresAt).getTime() - Date.now()) / (1000 * 60 * 60 * 24)))
    : null;
  const isTrial = subscriptionStatus === 'trialing';
  const expiryWarning = daysLeft !== null && daysLeft <= 7 && !isReadOnly;

  const workspaceQuery = useQuery({
    ...workspaceMetadataQuery(user?.id ?? '', workspaceId),
    enabled: !!user && !!workspaceId,
  });
  const workspace = (workspaceQuery.data as Workspace | null | undefined) ?? null;
  const [mainTab, setMainTab] = useState<MainTab>(
    initialTab === 'team' ? 'team' : initialTab === 'warroom' ? 'warroom' : 'chat'
  );

  const mainTabRef = useRef<MainTab>(mainTab);
  const setMainTabLogged = useCallback((tab: MainTab, trigger: string) => {
    const from = mainTabRef.current;
    console.log('[WorkspaceHub] setMainTab:', from, '→', tab, '(' + trigger + ')');
    logTabChange(from, tab as TabValue, trigger, workspaceId);

    // Fire-and-forget: count messages in this workspace at the time of the tab switch.
    // This correlates with the bug only appearing in workspaces with chat history.
    supabase
      .from('workspace_chat_messages')
      .select('id', { count: 'exact', head: true })
      .eq('workspace_id', workspaceId)
      .then(({ count }) => {
        debugLog('tab_change_msg_count', {
          from: from as string,
          to: tab as string,
          trigger,
          message_count: count ?? null,
        }, workspaceId);
      }, () => {});

    mainTabRef.current = tab;
    setMainTab(tab);
  }, [workspaceId]);
  const [pendingPrompt, setPendingPrompt] = useState<string | undefined>(undefined);
  const [isMobileViewport, setIsMobileViewport] = useState(() =>
    typeof window !== 'undefined' && window.matchMedia('(max-width: 1023px)').matches,
  );
  const [resyncing, setResyncing] = useState(false);
  const [warRoomKey, setWarRoomKey] = useState(0);
  const [showUpgrade, setShowUpgrade] = useState(false);
  const [discussedKeys, setDiscussedKeys] = useState<Set<string>>(new Set());

  useEffect(() => {
    const mediaQuery = window.matchMedia('(max-width: 1023px)');
    const handleViewportChange = (event: MediaQueryListEvent) => setIsMobileViewport(event.matches);
    mediaQuery.addEventListener('change', handleViewportChange);
    return () => mediaQuery.removeEventListener('change', handleViewportChange);
  }, []);

  function handleDiscuss(prompt: string) {
    setPendingPrompt(prompt);
    setMainTabLogged('chat', 'pendingPrompt');
  }

  async function handleResynthesis() {
    setResyncing(true);
    try {
      if (!session?.access_token) return;

      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 180000);

      let res: Response | null = null;
      try {
        res = await fetch(`${supabaseUrl}/functions/v1/workspace-synthesize`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${session.access_token}`,
          },
          body: JSON.stringify({ workspace_id: workspaceId }),
          signal: controller.signal,
        });
      } catch {
        return;
      } finally {
        clearTimeout(timeout);
      }

      let json: { error?: string } = {};
      try { json = await res!.json(); } catch { /* non-critical */ }

      if (!json.error) {
        setWarRoomKey(k => k + 1);
        setDiscussedKeys(new Set());
      }
    } finally {
      setResyncing(false);
    }
  }

  /* ── Loading state ── */
  if (accessLoading) {
    return (
      <div className="flex flex-col overflow-hidden" style={{ height: 'calc(100dvh - 3.5rem)', background: 'var(--app-bg)' }}>
        {/* Header skeleton */}
        <div
          className="flex-shrink-0 flex items-center gap-3 px-4 lg:px-5 py-3"
          style={{ background: 'var(--app-surface-raised)', borderBottom: '1px solid var(--app-border)' }}
        >
          <div className="skeleton w-7 h-7" />
          <div className="skeleton w-7 h-7" />
          <div className="flex-1 space-y-2">
            <div className="skeleton h-3 w-36" />
            <div className="skeleton h-2.5 w-52" />
          </div>
          <div className="skeleton w-28 h-7" />
        </div>
        {/* Panel skeleton */}
        <div className="flex-1 flex p-3 gap-3">
          <div className="skeleton flex-1" style={{ border: '1px solid var(--app-border)' }} />
          <div className="skeleton hidden lg:block w-[420px]" style={{ border: '1px solid var(--app-border)' }} />
        </div>
      </div>
    );
  }

  /* ── Access denied ── */
  if (!canAccess) {
    return (
      <div className="min-h-screen flex items-center justify-center p-4" style={{ background: 'var(--app-bg)' }}>
        <div className="text-center max-w-xs" style={{ color: 'var(--app-text-primary)' }}>
          <div className="w-12 h-12 flex items-center justify-center mx-auto mb-5" style={{ background: 'var(--app-surface)', border: '1px solid var(--app-border)' }}>
            <Lock className="w-5 h-5" style={{ color: 'var(--app-text-muted)' }} />
          </div>
          <p className="section-label mb-2">Access Restricted</p>
          <h2 className="text-base font-semibold mb-2" style={{ color: 'var(--app-text-primary)' }}>Private Workspace</h2>
          <p className="text-sm leading-relaxed mb-5" style={{ color: 'var(--app-text-secondary)' }}>
            {accessError ? 'Workspace access could not be verified. Please try again.' : 'This workspace is invite-only. Contact the workspace owner for access.'}
          </p>
          <button onClick={onBack} className="btn-ghost text-xs">
            Return to overview
          </button>
        </div>
      </div>
    );
  }

  /* ── Read-only overlay ── */
  function ReadOnlyOverlay() {
    return (
      <div
        className="absolute inset-0 z-10 flex items-center justify-center"
        style={{ background: 'rgba(240,243,247,0.92)', backdropFilter: 'blur(3px)' }}
      >
        <div className="text-center px-6">
          <div className="w-10 h-10 flex items-center justify-center mx-auto mb-3" style={{ background: 'var(--negative-bg)', border: '1px solid var(--negative)' }}>
            <Lock className="w-4 h-4" style={{ color: 'var(--negative)' }} />
          </div>
          <p className="text-sm font-semibold mb-1" style={{ color: 'var(--app-text-primary)' }}>Read-only mode</p>
          <p className="text-xs mb-4" style={{ color: 'var(--app-text-secondary)' }}>Upgrade to resume analysis sessions.</p>
          <button
            onClick={() => setShowUpgrade(true)}
            className="btn-primary"
          >
            Upgrade plan
          </button>
        </div>
      </div>
    );
  }

  const planLabel = plan === 'enterprise' ? 'ENTERPRISE' : plan === 'business' ? 'BUSINESS' : plan === 'team' ? 'TEAM' : 'PRO';

  return (
    <div
      className="flex flex-col overflow-hidden lg:!h-[calc(100dvh-3.5rem-env(safe-area-inset-top,0px))]"
      style={{
        height: 'calc(100dvh - 3.5rem - env(safe-area-inset-top, 0px))',
        background: 'var(--app-bg)',
      }}
    >

      {/* ── Top header bar ── */}
      <div
        className="flex-shrink-0"
        style={{ background: 'var(--app-surface-raised)', borderBottom: '1px solid var(--app-border)' }}
      >

        {/* Main header row */}
        <div className="flex items-center gap-3 px-4 lg:px-5 py-2.5">
          <button
            onClick={onBack}
            className="btn-ghost p-1.5"
            aria-label="Back to workspaces"
          >
            <ArrowLeft className="w-3.5 h-3.5" />
          </button>

          {/* Workspace identity mark */}
          <div
            className="flex-shrink-0 w-7 h-7 flex items-center justify-center text-xs font-black"
            style={{ background: 'var(--ink-50)', color: 'var(--ink-900)', border: '1px solid var(--app-border)' }}
            title={workspace?.name}
          >
            {(workspace?.name || 'W').slice(0, 1).toUpperCase()}
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h1 className="text-sm font-semibold truncate" style={{ color: 'var(--app-text-primary)' }}>
                {workspace?.name || 'Private Workspace'}
              </h1>
              {workspaceIsPro && (
                <span className="badge badge-amber flex-shrink-0">{planLabel}</span>
              )}
              {isTrial && !isReadOnly && daysLeft !== null && (
                <span className="hidden sm:inline-flex items-center gap-1 badge badge-slate flex-shrink-0">
                  <Clock className="w-2.5 h-2.5" />
                  {daysLeft}d
                </span>
              )}
            </div>
            {workspace?.description && (
              <p className="text-xs truncate hidden sm:block mt-0.5" style={{ color: 'var(--app-text-muted)' }}>
                {workspace.description}
              </p>
            )}
          </div>

          <div className="flex items-center gap-2 flex-shrink-0">
            {workspaceIsPro && !isReadOnly && (
              <button
                onClick={handleResynthesis}
                disabled={resyncing}
                className="hidden lg:flex btn-primary gap-1.5 disabled:opacity-50"
                style={{ padding: '0.375rem 0.875rem', fontSize: '0.75rem' }}
              >
                {resyncing ? <Loader2 className="w-3 h-3 animate-spin" /> : <RefreshCw className="w-3 h-3" />}
                {resyncing ? 'Synthesizing' : 'Synthesize'}
              </button>
            )}
            {isAdmin && (
              <button
                onClick={onSettings}
                className="btn-ghost gap-1.5"
                style={{ padding: '0.375rem 0.625rem', fontSize: '0.75rem' }}
              >
                <Settings className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Settings</span>
              </button>
            )}
          </div>
        </div>

        {/* Banners */}
        {expiryWarning && (
          <div
            className="px-4 lg:px-5 py-2 flex items-center gap-3"
            style={{ background: 'var(--signal-bg)', borderTop: '1px solid var(--signal)' }}
          >
            <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" style={{ color: 'var(--signal)' }} />
            <p className="text-xs flex-1" style={{ color: 'var(--app-text-secondary)' }}>
              <span className="font-semibold">Trial expires in {daysLeft} day{daysLeft === 1 ? '' : 's'}.</span>
              {' '}Upgrade to maintain access.
            </p>
            <button
              onClick={() => setShowUpgrade(true)}
              className="btn-primary flex-shrink-0"
              style={{ padding: '0.25rem 0.75rem', fontSize: '0.6875rem' }}
            >
              Upgrade
            </button>
          </div>
        )}
        {isReadOnly && (
          <div
            className="px-4 lg:px-5 py-2 flex items-center gap-3"
            style={{ background: 'var(--negative-bg)', borderTop: '1px solid var(--negative)' }}
          >
            <AlertTriangle className="w-3.5 h-3.5 flex-shrink-0" style={{ color: 'var(--negative)' }} />
            <p className="text-xs flex-1" style={{ color: 'var(--app-text-secondary)' }}>
              <span className="font-semibold">Trial expired — read-only.</span>
              {' '}Your data is preserved. Upgrade to restore full access.
            </p>
            <button
              onClick={() => setShowUpgrade(true)}
              className="btn-primary flex-shrink-0"
              style={{ padding: '0.25rem 0.75rem', fontSize: '0.6875rem' }}
            >
              Upgrade
            </button>
          </div>
        )}

        {/* ── Mobile tab bar ── */}
        <div
          className="lg:hidden flex flex-shrink-0"
          style={{ borderTop: '1px solid var(--app-border)', background: 'var(--app-surface)' }}
        >
          {([ 
            { id: 'team' as MainTab, label: 'Team Chat', Icon: Users },
            { id: 'chat' as MainTab, label: 'Multiplayer AI', Icon: MessageSquare },
            { id: 'warroom' as MainTab, label: 'War Room', Icon: Activity },
          ] as const).map(({ id, label, Icon }) => {
            const active = mainTab === id;
            return (
              <button
                key={id}
                onClick={() => setMainTabLogged(id, 'desktop-tab-click')}
                className="flex-1 flex items-center justify-center gap-2 py-2.5 text-xs font-semibold transition-colors relative"
                style={{
                  color: active ? 'var(--signal)' : 'var(--app-text-muted)',
                  borderBottom: active ? '2px solid var(--signal)' : '2px solid transparent',
                  background: active ? 'var(--signal-bg)' : 'transparent',
                }}
              >
                <Icon className="w-3.5 h-3.5" />
                {label}
                {id === 'warroom' && !workspaceIsPro && (
                  <span className="badge badge-amber absolute top-1.5 right-2" style={{ padding: '0.1rem 0.35rem', fontSize: '9px' }}>PRO</span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* ── Main content area ── */}
      <div className="flex-1 overflow-hidden flex flex-col lg:flex-row">

        {/* ── MOBILE: Chat tab ── */}
        {isMobileViewport && mainTab === 'chat' && (
          <div className="flex-1 overflow-hidden" style={{ marginBottom: '3rem' }}>
            <PageErrorBoundary resetKey={`m-chat-${workspaceId}`}>
            <div className="h-full overflow-hidden relative flex flex-col" style={{ background: 'var(--app-surface-raised)' }}>
              {isReadOnly && <ReadOnlyOverlay />}
              <WorkspaceChat
                workspaceId={workspaceId}
                workspaceName={workspace?.name || 'Workspace'}
                workspaceTopic={workspace?.description}
                initialPrompt={pendingPrompt}
                onPromptConsumed={() => setPendingPrompt(undefined)}
                onAgentsReplied={() => {}}
                isPro={workspaceIsPro}
                onUpgrade={() => setShowUpgrade(true)}
              />
            </div>
            </PageErrorBoundary>
          </div>
        )}

        {/* ── MOBILE: Team Chat tab ── */}
        {isMobileViewport && mainTab === 'team' && (
          <div className="flex-1 overflow-hidden" style={{ marginBottom: '3rem' }}>
            <PageErrorBoundary resetKey={`m-team-${workspaceId}`}>
            <div className="h-full overflow-hidden relative flex flex-col" style={{ background: 'var(--app-surface-raised)' }}>
              {isReadOnly && <ReadOnlyOverlay />}
              <TeamChat
                workspaceId={workspaceId}
                workspaceName={workspace?.name || 'Workspace'}
              />
            </div>
            </PageErrorBoundary>
          </div>
        )}

        {/* ── MOBILE: War Room tab ── */}
        {isMobileViewport && mainTab === 'warroom' && (
          <div className="flex-1 overflow-y-auto" style={{ marginBottom: '3rem', paddingBottom: '1.5rem' }}>
            <PageErrorBoundary resetKey={`m-war-${workspaceId}`}>
            {workspaceIsPro ? (
              <WorkspaceWarRoom
                key={warRoomKey}
                workspaceId={workspaceId}
                workspaceName={workspace?.name || 'Workspace'}
                workspaceTopic={workspace?.description}
                onDiscuss={p => { handleDiscuss(p); setMainTabLogged('chat', 'discuss'); }}
                discussedKeys={discussedKeys}
                onDiscussed={key => setDiscussedKeys(prev => new Set([...prev, key]))}
              />
            ) : (
              <div className="p-4">
                <WarRoomLockedState onUpgrade={() => setShowUpgrade(true)} />
              </div>
            )}
            </PageErrorBoundary>
          </div>
        )}

        {/* ── DESKTOP: Side-by-side panels ── */}
        {!isMobileViewport && (
        <div className="flex flex-1 overflow-hidden">

          {/* Left: Multiplayer AI or Team Chat (switches based on tab) */}
          <div
            className="flex-1 min-w-0 max-w-[900px] mx-auto w-full flex flex-col overflow-hidden"
            style={{ borderRight: '1px solid var(--app-border)' }}
          >
            {/* Desktop tab switcher */}
            <div
              className="flex-shrink-0 flex items-center px-3 pt-2 gap-1"
              style={{ borderBottom: '1px solid var(--app-border)', background: 'var(--app-surface)' }}
            >
              {([
                { id: 'team' as MainTab, label: 'Team Chat', Icon: Users },
                { id: 'chat' as MainTab, label: 'Multiplayer AI', Icon: MessageSquare },
              ] as const).map(({ id, label, Icon }) => {
                const active = mainTab === id;
                return (
                  <button
                    key={id}
                    onClick={() => setMainTabLogged(id, 'desktop-tab-click')}
                    className="flex items-center gap-2 px-3 py-2 text-xs font-semibold transition-colors relative"
                    style={{
                      color: active ? 'var(--signal)' : 'var(--app-text-muted)',
                      borderBottom: active ? '2px solid var(--signal)' : '2px solid transparent',
                      background: active ? 'var(--signal-bg)' : 'transparent',
                      marginBottom: '-1px',
                    }}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    {label}
                  </button>
                );
              })}
              {mainTab === 'chat' && (
                <div className="ml-auto flex items-center gap-1.5 pr-2">
                  <span className="w-1.5 h-1.5 rounded-full" style={{ background: 'var(--positive)' }} />
                  <span className="text-xs" style={{ color: 'var(--app-text-muted)' }}>Live</span>
                </div>
              )}
            </div>

            {mainTab === 'team' ? (
              <PageErrorBoundary resetKey={`d-team-${workspaceId}`}>
              <TeamChat
                workspaceId={workspaceId}
                workspaceName={workspace?.name || 'Workspace'}
              />
              </PageErrorBoundary>
            ) : (
              <PageErrorBoundary resetKey={`d-chat-${workspaceId}`}>
              <div className="flex-1 min-h-0 relative" style={{ background: 'var(--app-surface-raised)' }}>
                {isReadOnly && <ReadOnlyOverlay />}
                <div className="h-full p-5">
                  <WorkspaceChat
                    workspaceId={workspaceId}
                    workspaceName={workspace?.name || 'Workspace'}
                    workspaceTopic={workspace?.description}
                    initialPrompt={pendingPrompt}
                    onPromptConsumed={() => setPendingPrompt(undefined)}
                    onAgentsReplied={() => {}}
                    isPro={workspaceIsPro}
                    onUpgrade={() => setShowUpgrade(true)}
                  />
                </div>
              </div>
              </PageErrorBoundary>
            )}
          </div>

          {/* Right: War Room */}
          <div
            className="flex-shrink-0 flex flex-col overflow-hidden"
            style={{ width: 'clamp(440px, 38vw, 640px)' }}
          >
            {/* Panel header */}
            <div
              className="flex-shrink-0 flex items-center gap-2.5 px-5 py-2.5"
              style={{ borderBottom: '1px solid var(--app-border)', background: 'var(--app-surface)' }}
            >
              <Activity className="w-3.5 h-3.5 flex-shrink-0" style={{ color: 'var(--signal)' }} />
              <span className="section-label">War Room</span>
              {!workspaceIsPro && (
                <span className="badge badge-amber" style={{ fontSize: '9px' }}>PRO</span>
              )}
              <div className="ml-auto flex items-center gap-2">
                {workspaceIsPro && !isReadOnly && (
                  <button
                    onClick={handleResynthesis}
                    disabled={resyncing}
                    className="btn-primary disabled:opacity-50"
                    style={{ padding: '0.25rem 0.75rem', fontSize: '0.6875rem', gap: '0.375rem' }}
                  >
                    {resyncing ? <Loader2 className="w-2.5 h-2.5 animate-spin" /> : <RefreshCw className="w-2.5 h-2.5" />}
                    {resyncing ? 'Synthesizing' : 'Synthesize'}
                  </button>
                )}
              </div>
            </div>

            {/* War Room content */}
            <div className="flex-1 min-h-0 overflow-y-auto" style={{ background: 'var(--app-bg)' }}>
              {workspaceIsPro ? (
                <WorkspaceWarRoom
                  key={warRoomKey}
                  workspaceId={workspaceId}
                  workspaceName={workspace?.name || 'Workspace'}
                  workspaceTopic={workspace?.description}
                  onDiscuss={handleDiscuss}
                  discussedKeys={discussedKeys}
                  onDiscussed={key => setDiscussedKeys(prev => new Set([...prev, key]))}
                />
              ) : (
                <div className="p-5">
                  <WarRoomLockedState onUpgrade={() => setShowUpgrade(true)} />
                </div>
              )}
            </div>
          </div>
        </div>
        )}
      </div>

      {showUpgrade && (
        <UpgradePrompt
          context={isReadOnly ? 'trial_exhausted' : 'workspace'}
          onClose={() => setShowUpgrade(false)}
          onUpgrade={() => { setShowUpgrade(false); onNavigate('pricing'); }}
        />
      )}

    </div>
  );
}
