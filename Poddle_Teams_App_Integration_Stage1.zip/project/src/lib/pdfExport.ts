import { supabase } from './supabase';
import type { ChartData, AgentFigures } from '../components/ConsensusCharts';

const AGENT_DISPLAY_NAMES: Record<string, string> = {
  risk_analyst: 'Risk Analyst',
  devils_advocate: "Devil's Advocate",
  innovation_scout: 'Innovation Lead',
  market_analyst: 'Market Analyst',
  financial_strategist: 'Financial Strategist',
  execution_lead: 'Execution Lead',
  people_advisor: 'People Advisor',
  consensus: 'Consensus',
};

function formatAgentName(role: string): string {
  return AGENT_DISPLAY_NAMES[role] ?? role.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
}

async function logExport(exportType: string, _workspaceName: string, workspaceId?: string) {
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return;
  supabase.from('pdf_exports').insert({
    user_id: user.id,
    workspace_id: workspaceId ?? null,
    export_type: exportType,
  }).then(() => {});
}

export interface ChatMessageExport {
  role: 'user' | 'assistant';
  content: string;
  agent_name?: string;
  agent_role?: string;
  created_at: string;
  chart_data?: ChartData | null;
  figures?: AgentFigures | null;
}

export interface KeyDecision {
  decision: string;
  status: string;
  rationale: string;
  owner?: string;
}

export interface WarRoomExport {
  workspaceName: string;
  workspaceId?: string;
  topic?: string;
  generatedAt: string;
  messageCount: number;
  decisionHealthScore: number;
  healthRationale?: string;
  recommendation?: string | null;
  keyDecisions?: KeyDecision[];
  financialScore?: number | null;
  operationalScore?: number | null;
  alignmentScore?: number | null;
  decisionVelocity?: string | null;
  confidenceTrajectory?: string | null;
  consensusPoints: Array<{ text: string; confidence: number; source_count: number }>;
  conflictZones: Array<{ topic: string; agent_a: string; position_a: string; agent_b: string; position_b: string; tension_level: number }>;
  openQuestions: Array<{ question: string; urgency: string }>;
  riskSignals: Array<{ signal: string; severity: string; category: string }>;
  blindSpots: Array<{ area: string; description: string }>;
  actionItems?: Array<{ text: string; priority: string; status: string; source: string; source_area?: string }>;
  financialMetrics?: Array<{ metric: string; value: string; confidence: string; note: string }>;
  operationalMetrics?: Array<{ metric: string; status: string; note: string }>;
  nonFinancialMetrics?: Array<{ metric: string; signal: string; note: string }>;
  opportunitySignals?: Array<{ title: string; description: string; confidence: string; source: string }>;
  cognitiveBiasFlags?: Array<{ bias_name: string; explanation: string; counter_question: string }>;
}

export interface BoardBriefExport {
  workspaceName: string;
  workspaceId?: string;
  topic?: string;
  generatedAt: string;
  decisionHealthScore: number;
  healthRationale?: string;
  keyDecisions?: KeyDecision[];
  financialScore?: number | null;
  operationalScore?: number | null;
  alignmentScore?: number | null;
  consensusPoints: Array<{ text: string; confidence: number }>;
  riskSignals: Array<{ signal: string; severity: string }>;
  actionItems: Array<{ text: string; priority: string; status: string; source_area?: string }>;
  opportunitySignals?: Array<{ title: string; description: string; confidence: string; source: string }>;
  synthesisRunNumber?: number;
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function escapeHtml(text: string): string {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/\n/g, '<br>');
}

function formatDate(iso: string): string {
  try {
    return new Date(iso).toLocaleString(undefined, {
      year: 'numeric', month: 'short', day: 'numeric',
      hour: '2-digit', minute: '2-digit',
    });
  } catch {
    return iso;
  }
}

function scoreColor(s: number): string {
  return s >= 75 ? '#1e7a52' : s >= 55 ? '#b35c10' : s >= 35 ? '#a8292a' : '#7a1d1d';
}

function scoreLabel(s: number): string {
  return s >= 75 ? 'Sharp' : s >= 55 ? 'Developing' : s >= 35 ? 'Fragmented' : 'Critical';
}

function severityColor(sev: string): string {
  const map: Record<string, string> = { critical: '#dc2626', high: '#f59e0b', medium: '#b8860b', low: '#94a3b8' };
  return map[sev?.toLowerCase()] || '#94a3b8';
}


function severityText(sev: string): string {
  const map: Record<string, string> = { critical: '#a8292a', high: '#b35c10', medium: '#8a6508', low: '#5D6B82' };
  return map[sev?.toLowerCase()] || '#475569';
}

// ─── SVG Generators (render in print perfectly) ───────────────────────────────

function svgScoreRing(score: number): string {
  const safe = Math.max(0, Math.min(100, score));
  const r = 44, cx = 56, cy = 56, sw = 9;
  const circ = 2 * Math.PI * r;
  const dash = (safe / 100) * circ;
  const c = scoreColor(safe);
  return `
    <svg width="112" height="112" viewBox="0 0 112 112" xmlns="http://www.w3.org/2000/svg">
      <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="#1f2535" stroke-width="${sw}"/>
      <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${c}" stroke-width="${sw}"
        stroke-dasharray="${dash.toFixed(1)} ${(circ - dash).toFixed(1)}"
        stroke-linecap="round"
        transform="rotate(-90 ${cx} ${cy})"/>
      <text x="${cx}" y="${cy - 6}" text-anchor="middle" font-family="-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif"
        font-size="22" font-weight="900" fill="${c}">${safe}</text>
      <text x="${cx}" y="${cy + 12}" text-anchor="middle" font-family="-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif"
        font-size="9" fill="#94a3b8">/ 100</text>
    </svg>`;
}

function svgConsensusBar(confidence: number, color: string): string {
  const safe = Math.max(0, Math.min(100, confidence));
  const totalW = 160, h = 7, r = 3;
  const fillW = Math.max(r * 2, (safe / 100) * totalW);
  return `
    <svg width="${totalW}" height="${h}" viewBox="0 0 ${totalW} ${h}" xmlns="http://www.w3.org/2000/svg">
      <rect x="0" y="0" width="${totalW}" height="${h}" rx="${r}" fill="#1f2535"/>
      <rect x="0" y="0" width="${fillW.toFixed(1)}" height="${h}" rx="${r}" fill="${color}"/>
    </svg>`;
}

// ─── Chat Chart SVG Generators (mirror ConsensusCharts component) ───────────────

const CHART_FONT = "-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif";
const RISK_COLORS_PDF: Record<string, string> = {
  Market: '#0ea5e9', Execution: '#f59e0b', Financial: '#ef4444',
  Technology: '#8b5cf6', People: '#10b981', Regulatory: '#64748b',
};
const CONFIDENCE_COLOR_PDF = (v: number) => v >= 70 ? '#10b981' : v >= 40 ? '#f59e0b' : '#ef4444';
const ALIGNMENT_COLOR_PDF = (v: number) => v >= 70 ? '#10b981' : v >= 40 ? '#f59e0b' : '#ef4444';
const FIGURE_COLOR_PDF = '#0ea5e9';
const CATEGORY_COLORS_PDF = ['#0ea5e9', '#f59e0b', '#10b981', '#ef4444', '#8b5cf6', '#64748b', '#ec4899', '#14b8a6'];

function svgAgentConfidence(data: ChartData['agent_confidence']): string {
  if (!data?.length) return '';
  const barHeight = 28, gap = 10, labelWidth = 120, trackWidth = 180;
  const height = data.length * (barHeight + gap) + 20;
  const width = labelWidth + trackWidth + 50;
  let bars = '';
  data.forEach((item, i) => {
    const y = i * (barHeight + gap);
    const barW = Math.max(2, (item.confidence / 100) * trackWidth);
    const name = item.agent_name.length > 16 ? item.agent_name.slice(0, 15) + '…' : item.agent_name;
    bars += `<text x="0" y="${y + barHeight / 2 + 4}" font-family="${CHART_FONT}" font-size="12" font-weight="500" fill="#475569">${escapeHtml(name)}</text>`;
    bars += `<rect x="${labelWidth}" y="${y}" width="${trackWidth}" height="${barHeight}" rx="4" fill="#f1f5f9"/>`;
    bars += `<rect x="${labelWidth}" y="${y}" width="${barW.toFixed(1)}" height="${barHeight}" rx="4" fill="${CONFIDENCE_COLOR_PDF(item.confidence)}"/>`;
    bars += `<text x="${labelWidth + trackWidth + 8}" y="${y + barHeight / 2 + 4}" font-family="${CHART_FONT}" font-size="12" font-weight="bold" fill="#334155">${Math.round(item.confidence)}%</text>`;
  });
  return `<svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg" style="display:block;max-width:100%;">${bars}</svg>`;
}

function svgRiskDonut(data: ChartData['risk_distribution']): string {
  if (!data?.length) return '';
  const total = data.reduce((s, d) => s + d.count, 0);
  if (total === 0) return '';
  const size = 180, radius = 70, cx = size / 2, cy = size / 2, sw = 28;
  let cumulative = 0;
  let paths = '';
  let legend = '';
  data.filter(d => d.count > 0).forEach(d => {
    const fraction = d.count / total;
    const startAngle = (cumulative / total) * 2 * Math.PI - Math.PI / 2;
    cumulative += d.count;
    const endAngle = (cumulative / total) * 2 * Math.PI - Math.PI / 2;
    const x1 = cx + radius * Math.cos(startAngle);
    const y1 = cy + radius * Math.sin(startAngle);
    const x2 = cx + radius * Math.cos(endAngle);
    const y2 = cy + radius * Math.sin(endAngle);
    const largeArc = fraction > 0.5 ? 1 : 0;
    const path = `M ${x1.toFixed(1)} ${y1.toFixed(1)} A ${radius} ${radius} 0 ${largeArc} 1 ${x2.toFixed(1)} ${y2.toFixed(1)}`;
    const color = RISK_COLORS_PDF[d.category] || '#94a3b8';
    paths += `<path d="${path}" fill="none" stroke="${color}" stroke-width="${sw}" stroke-linecap="butt"/>`;
    legend += `<div style="display:flex;align-items:center;gap:5px;margin-bottom:3px;"><span style="display:inline-block;width:11px;height:11px;border-radius:2px;background:${color};flex-shrink:0;"></span><span style="font-size:9pt;color:#475569;">${escapeHtml(d.category)}</span><span style="font-size:9pt;font-weight:700;color:#1e293b;margin-left:auto;">${d.count}</span></div>`;
  });
  const centerText = `<text x="${cx}" y="${cy - 6}" text-anchor="middle" font-family="${CHART_FONT}" font-size="28" font-weight="bold" fill="#1e293b">${total}</text><text x="${cx}" y="${cy + 16}" text-anchor="middle" font-family="${CHART_FONT}" font-size="11" fill="#94a3b8">risks</text>`;
  return `<div style="display:flex;flex-wrap:wrap;align-items:flex-start;gap:14px;">
    <svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" xmlns="http://www.w3.org/2000/svg" style="flex-shrink:0;">${paths}${centerText}</svg>
    <div style="display:flex;flex-direction:column;gap:1px;padding-top:4px;min-width:100px;">${legend}</div>
  </div>`;
}

function svgAlignmentHistogram(data: ChartData['alignment_scores']): string {
  if (!data?.length) return '';
  const barWidth = 36, gap = 16, chartHeight = 120, baseline = chartHeight - 20;
  const width = data.length * (barWidth + gap) + 20;
  let bars = `<line x1="10" y1="${baseline}" x2="${width - 10}" y2="${baseline}" stroke="#e2e8f0" stroke-width="1"/>`;
  data.forEach((item, i) => {
    const x = 10 + i * (barWidth + gap);
    const barH = (item.score / 100) * (baseline - 10);
    const y = baseline - barH;
    bars += `<rect x="${x}" y="${y.toFixed(1)}" width="${barWidth}" height="${barH.toFixed(1)}" rx="3" fill="${ALIGNMENT_COLOR_PDF(item.score)}"/>`;
    bars += `<text x="${x + barWidth / 2}" y="${baseline + 16}" text-anchor="middle" font-family="${CHART_FONT}" font-size="11" fill="#64748b">${escapeHtml(item.dimension)}</text>`;
    bars += `<text x="${x + barWidth / 2}" y="${y - 5}" text-anchor="middle" font-family="${CHART_FONT}" font-size="11" font-weight="bold" fill="#334155">${Math.round(item.score)}</text>`;
  });
  return `<svg width="${width}" height="${chartHeight + 30}" viewBox="0 0 ${width} ${chartHeight + 30}" xmlns="http://www.w3.org/2000/svg" style="display:block;max-width:100%;">${bars}</svg>`;
}

function svgFiguresChart(data: AgentFigures['figures']): string {
  if (!data?.length) return '';
  const barHeight = 22, gap = 8, labelWidth = 140, trackWidth = 140;
  const maxVal = Math.max(...data.map(d => Math.abs(d.value)), 1);
  const height = data.length * (barHeight + gap) + 20;
  const width = labelWidth + trackWidth + 60;
  let bars = '';
  data.forEach((item, i) => {
    const y = i * (barHeight + gap);
    const barW = Math.max(2, (Math.abs(item.value) / maxVal) * trackWidth);
    const label = item.label.length > 18 ? item.label.slice(0, 17) + '…' : item.label;
    const displayVal = item.unit === '$' ? `$${item.value.toLocaleString()}` : `${item.value}${item.unit || ''}`;
    bars += `<text x="0" y="${y + barHeight / 2 + 4}" font-family="${CHART_FONT}" font-size="11" font-weight="500" fill="#475569">${escapeHtml(label)}</text>`;
    bars += `<rect x="${labelWidth}" y="${y}" width="${trackWidth}" height="${barHeight}" rx="3" fill="#f1f5f9"/>`;
    bars += `<rect x="${labelWidth}" y="${y}" width="${barW.toFixed(1)}" height="${barHeight}" rx="3" fill="${FIGURE_COLOR_PDF}"/>`;
    bars += `<text x="${labelWidth + trackWidth + 8}" y="${y + barHeight / 2 + 4}" font-family="${CHART_FONT}" font-size="11" font-weight="bold" fill="#334155">${escapeHtml(displayVal)}</text>`;
  });
  return `<svg width="${width}" height="${height}" viewBox="0 0 ${width} ${height}" xmlns="http://www.w3.org/2000/svg" style="display:block;max-width:100%;">${bars}</svg>`;
}

function svgCategoriesChart(data: AgentFigures['categories']): string {
  if (!data?.length) return '';
  const total = data.reduce((s, d) => s + Math.abs(d.value), 0);
  if (total === 0) return '';
  const size = 150, radius = 58, cx = size / 2, cy = size / 2, sw = 24;
  let cumulative = 0;
  let paths = '';
  let legend = '';
  data.forEach((d, i) => {
    const fraction = Math.abs(d.value) / total;
    const startAngle = (cumulative / total) * 2 * Math.PI - Math.PI / 2;
    cumulative += Math.abs(d.value);
    const endAngle = (cumulative / total) * 2 * Math.PI - Math.PI / 2;
    const x1 = cx + radius * Math.cos(startAngle);
    const y1 = cy + radius * Math.sin(startAngle);
    const x2 = cx + radius * Math.cos(endAngle);
    const y2 = cy + radius * Math.sin(endAngle);
    const largeArc = fraction > 0.5 ? 1 : 0;
    const path = `M ${x1.toFixed(1)} ${y1.toFixed(1)} A ${radius} ${radius} 0 ${largeArc} 1 ${x2.toFixed(1)} ${y2.toFixed(1)}`;
    const color = CATEGORY_COLORS_PDF[i % CATEGORY_COLORS_PDF.length];
    paths += `<path d="${path}" fill="none" stroke="${color}" stroke-width="${sw}" stroke-linecap="butt"/>`;
    const val = d.unit === '%' ? `${d.value}%` : String(d.value);
    legend += `<div style="display:flex;align-items:center;gap:5px;margin-bottom:3px;"><span style="display:inline-block;width:10px;height:10px;border-radius:2px;background:${color};flex-shrink:0;"></span><span style="font-size:9pt;color:#475569;">${escapeHtml(d.label)}</span><span style="font-size:9pt;font-weight:700;color:#1e293b;margin-left:auto;">${escapeHtml(val)}</span></div>`;
  });
  return `<div style="display:flex;flex-wrap:wrap;align-items:flex-start;gap:12px;"><svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" xmlns="http://www.w3.org/2000/svg" style="flex-shrink:0;">${paths}</svg><div style="display:flex;flex-direction:column;gap:1px;padding-top:4px;min-width:80px;">${legend}</div></div>`;
}

function svgConsensusCharts(data: ChartData): string {
  const parts: string[] = [];
  if (data.agent_confidence?.length) parts.push(svgAgentConfidence(data.agent_confidence));
  if (data.risk_distribution?.length) parts.push(svgRiskDonut(data.risk_distribution));
  if (data.alignment_scores?.length) parts.push(svgAlignmentHistogram(data.alignment_scores));
  if (!parts.length) return '';
  return `<div style="margin-top:10px;padding-top:8px;border-top:1px solid #e2e8f0;"><div style="font-size:7.5pt;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:8px;">Debate Analytics</div><div style="display:flex;flex-wrap:wrap;gap:16px;">${parts.map(p => `<div style="min-width:0;">${p}</div>`).join('')}</div></div>`;
}

function svgAgentFigures(figures: AgentFigures): string {
  const parts: string[] = [];
  if (figures.figures?.length) parts.push(svgFiguresChart(figures.figures));
  if (figures.categories?.length) parts.push(svgCategoriesChart(figures.categories));
  if (!parts.length) return '';
  return `<div style="margin-top:8px;padding-top:6px;border-top:1px solid #e2e8f0;"><div style="font-size:7.5pt;font-weight:700;color:#94a3b8;text-transform:uppercase;letter-spacing:0.06em;margin-bottom:6px;">Figures &amp; Breakdown</div><div style="display:flex;flex-direction:column;gap:12px;">${parts.join('')}</div></div>`;
}

function svgTensionBar(level: number): string {
  const safe = Math.max(0, Math.min(100, level));
  const totalW = 120, h = 6, r = 3;
  const fillW = Math.max(r * 2, (safe / 100) * totalW);
  const c = safe >= 70 ? '#a8292a' : safe >= 45 ? '#b35c10' : '#b8860b';
  return `
    <svg width="${totalW}" height="${h}" viewBox="0 0 ${totalW} ${h}" xmlns="http://www.w3.org/2000/svg">
      <rect x="0" y="0" width="${totalW}" height="${h}" rx="${r}" fill="#1f2535"/>
      <rect x="0" y="0" width="${fillW.toFixed(1)}" height="${h}" rx="${r}" fill="${c}"/>
    </svg>`;
}

function svgRiskMatrix(risks: WarRoomExport['riskSignals']): string {
  const SEVS = ['low', 'medium', 'high', 'critical'];
  const CATS = ['market', 'execution', 'financial', 'team', 'technology'];
  const cellW = 90, cellH = 38;
  const marginLeft = 56, marginBottom = 28;
  const W = marginLeft + CATS.length * cellW + 8;
  const H = marginBottom + SEVS.length * cellH + 8;

  let cells = '';
  // Draw grid
  for (let si = 0; si < SEVS.length; si++) {
    for (let ci = 0; ci < CATS.length; ci++) {
      const x = marginLeft + ci * cellW;
      const y = (SEVS.length - 1 - si) * cellH;
      const intensity = (si / (SEVS.length - 1)) * 0.08 * (ci / (CATS.length - 1) + 0.4);
      cells += `<rect x="${x}" y="${y}" width="${cellW}" height="${cellH}" fill="rgba(220,38,38,${intensity.toFixed(3)})" stroke="#1f2535" stroke-width="0.5"/>`;
    }
  }

  // Y-axis labels (severity)
  for (let si = 0; si < SEVS.length; si++) {
    const y = (SEVS.length - 1 - si) * cellH + cellH / 2 + 4;
    const c = severityText(SEVS[si]);
    cells += `<text x="${marginLeft - 6}" y="${y}" text-anchor="end" font-family="-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif" font-size="8" font-weight="700" fill="${c}" text-transform="capitalize">${SEVS[si]}</text>`;
  }

  // X-axis labels (category)
  for (let ci = 0; ci < CATS.length; ci++) {
    const x = marginLeft + ci * cellW + cellW / 2;
    const y = SEVS.length * cellH + 16;
    cells += `<text x="${x}" y="${y}" text-anchor="middle" font-family="-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif" font-size="8" fill="#64748b">${CATS[ci]}</text>`;
  }

  // Plot risk dots — track occupied cells to offset overlaps
  const occupied: Record<string, number> = {};
  risks.forEach((r, i) => {
    const si = SEVS.indexOf(r.severity?.toLowerCase());
    const ci = CATS.indexOf(r.category?.toLowerCase());
    if (si < 0 || ci < 0) return;
    const cellKey = `${si}-${ci}`;
    const offset = (occupied[cellKey] || 0) * 14;
    occupied[cellKey] = (occupied[cellKey] || 0) + 1;
    const cx = marginLeft + ci * cellW + cellW / 2 - offset;
    const cy = (SEVS.length - 1 - si) * cellH + cellH / 2;
    const c = severityColor(r.severity);
    cells += `<circle cx="${cx}" cy="${cy}" r="11" fill="${c}" stroke="white" stroke-width="2"/>`;
    cells += `<text x="${cx}" y="${cy + 4}" text-anchor="middle" font-family="-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif" font-size="9" font-weight="900" fill="white">${i + 1}</text>`;
  });

  return `
    <svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg"
      style="display:block;max-width:100%;">
      ${cells}
    </svg>`;
}

// ─── Base Styles ─────────────────────────────────────────────────────────────

const BASE_STYLES = `
  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
  html, body {
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Helvetica, Arial, sans-serif;
    font-size: 11pt;
    color: #111827;
    background: #fff;
    line-height: 1.55;
    width: 100%;
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
  }

  @media print {
    html, body {
      background: #fff !important;
      -webkit-print-color-adjust: exact !important;
      print-color-adjust: exact !important;
    }
    * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }
    /* Hide the screen toolbar */
    .print-toolbar { display: none !important; }
  }

  /* ── Screen toolbar (only shown on screen, hidden in print) ── */
  .print-toolbar {
    position: sticky;
    top: 0;
    z-index: 100;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 10px 20px;
    background: #07090f;
    color: #fff;
    gap: 12px;
  }
  .print-toolbar-title {
    font-size: 10pt; font-weight: 700; color: #b8860b; flex: 1;
    white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
  }
  .btn-print {
    display: inline-flex; align-items: center; gap: 6px;
    padding: 7px 18px;
    background: #b8860b; color: #07090f;
    border: none; border-radius: 3px;
    font-size: 9.5pt; font-weight: 700;
    cursor: pointer; white-space: nowrap;
  }
  .btn-print:hover { background: #d4a535; }
  .btn-close {
    display: inline-flex; align-items: center; gap: 6px;
    padding: 7px 14px;
    background: rgba(255,255,255,0.10); color: #e2e8f0;
    border: 1px solid rgba(255,255,255,0.15); border-radius: 3px;
    font-size: 9.5pt; font-weight: 600;
    cursor: pointer; white-space: nowrap;
    text-decoration: none;
  }
  .btn-close:hover { background: rgba(255,255,255,0.18); }

  .print-root {
    padding: 28px 36px 40px 36px;
    max-width: 820px;
    margin: 0 auto;
  }
  /* In print: small inner padding supplements the @page margins */
  @media print { .print-root { padding: 0 6px 0 6px; max-width: 100%; } }

  /* ── Logo ── */
  .logo-wrap { display: flex; align-items: center; gap: 8px; }
  .logo-box {
    width: 26px; height: 26px; border-radius: 4px;
    background: linear-gradient(135deg, #0e1117, #b8860b);
    display: flex; align-items: center; justify-content: center;
    flex-shrink: 0;
  }
  .logo-dot { width: 11px; height: 11px; border-radius: 50%; background: #07090f; }
  .logo-text { font-size: 13pt; font-weight: 900; letter-spacing: -0.03em; color: #111827; }
  .logo-sub { font-size: 8pt; font-weight: 600; color: #5D6B82; letter-spacing: 0.04em; text-transform: uppercase; }

  /* ── Per-page header + footer via @page margin boxes (Chrome-supported) ── */
  .page-header { display: none; }
  @media print {
    @page {
      margin: 22mm 24mm 18mm 24mm;
      size: A4;
      @top-right {
        content: "Poddle · poddleme.com";
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        font-size: 7pt;
        font-weight: 700;
        color: #94a3b8;
        letter-spacing: 0.04em;
        border-bottom: 1px solid #e2e8f0;
        padding-bottom: 4pt;
      }
      @bottom-left {
        content: "Human-AI Led Decision";
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        font-size: 7pt;
        font-weight: 700;
        color: #94a3b8;
        letter-spacing: 0.04em;
        border-top: 1px solid #e2e8f0;
        padding-top: 4pt;
      }
      @bottom-center {
        content: counter(page) " / " counter(pages);
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        font-size: 7pt;
        color: #94a3b8;
        border-top: 1px solid #e2e8f0;
        padding-top: 4pt;
      }
      @bottom-right {
        content: "Confidential";
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        font-size: 7pt;
        color: #94a3b8;
        border-top: 1px solid #e2e8f0;
        padding-top: 4pt;
      }
    }
  }

  /* ── Doc header ── */
  .doc-header {
    border-bottom: 2px solid #b8860b;
    padding-bottom: 14px; margin-bottom: 22px; margin-top: 18px;
  }
  .doc-header-top { display: flex; align-items: flex-start; justify-content: space-between; gap: 12px; flex-wrap: wrap; }
  .brand { font-size: 7.5pt; font-weight: 700; letter-spacing: 0.09em; text-transform: uppercase; color: #5D6B82; margin-bottom: 3px; }
  .title { font-size: 18pt; font-weight: 900; color: #111827; line-height: 1.2; }
  .subtitle { font-size: 9pt; color: #5D6B82; margin-top: 3px; }
  .meta-right { font-size: 8pt; font-weight: 600; color: #5D6B82; text-align: right; line-height: 1.7; }

  /* ── Score block ── */
  .score-block {
    background: #0e1117 !important;
    color: #e8ecf2;
    border: 1px solid #1f2535;
    border-radius: 4px;
    padding: 16px 22px;
    margin-bottom: 22px;
    display: flex; align-items: center; gap: 20px;
    page-break-inside: avoid; break-inside: avoid;
  }
  .score-label { font-size: 12pt; font-weight: 900; margin-bottom: 2px; }
  .score-sub { font-size: 8pt; color: #8892a4; margin-bottom: 8px; }
  .score-rationale { font-size: 9pt; color: #c8d0de; line-height: 1.55; }

  /* ── Sections ──
     No page-break-inside on the section wrapper — sections can span pages freely.
     Individual rows use avoid so a single row doesn't split mid-line.
  ── */
  .section { margin-bottom: 20px; }
  .section-hdr {
    display: flex; align-items: center; gap: 8px;
    padding: 7px 14px;
    border-radius: 8px 8px 0 0;
    font-size: 8.5pt; font-weight: 800;
    text-transform: uppercase; letter-spacing: 0.06em;
    border: 1px solid transparent; border-bottom: none;
    page-break-after: avoid; break-after: avoid;
  }
  .section-body { border-radius: 0 0 8px 8px; border: 1px solid transparent; border-top: none; }
  .row {
    padding: 10px 14px;
    border-top: 1px solid transparent;
    font-size: 9.5pt; line-height: 1.5;
    background: #fff !important;
    page-break-inside: avoid; break-inside: avoid;
  }

  /* Consensus */
  .sec-consensus .section-hdr { background: rgba(22,163,74,0.10) !important; color: #14532d; border-color: rgba(22,163,74,0.25); }
  .sec-consensus .section-body { border-color: rgba(22,163,74,0.2); }
  .sec-consensus .row { border-color: rgba(22,163,74,0.1); }

  /* Conflicts */
  .sec-conflicts .section-hdr { background: rgba(245,158,11,0.10) !important; color: #78350f; border-color: rgba(245,158,11,0.3); }
  .sec-conflicts .section-body { border-color: rgba(245,158,11,0.25); }
  .sec-conflicts .row { border-color: rgba(245,158,11,0.12); }

  /* Questions */
  .sec-questions .section-hdr { background: rgba(184,134,11,0.08) !important; color: #8a6508; border-color: rgba(184,134,11,0.22); }
  .sec-questions .section-body { border-color: rgba(232,184,75,0.2); }
  .sec-questions .row { border-color: rgba(232,184,75,0.08); }

  /* Risks */
  .sec-risks .section-hdr { background: rgba(220,38,38,0.08) !important; color: #7f1d1d; border-color: rgba(220,38,38,0.22); }
  .sec-risks .section-body { border-color: rgba(220,38,38,0.2); }
  .sec-risks .row { border-color: rgba(220,38,38,0.1); }

  /* Blind spots */
  .sec-blindspots .section-hdr { background: rgba(8,145,178,0.08) !important; color: #0c4a6e; border-color: rgba(8,145,178,0.22); }
  .sec-blindspots .section-body { border-color: rgba(8,145,178,0.2); }
  .sec-blindspots .row { border-color: rgba(8,145,178,0.1); }

  /* Actions */
  .sec-actions .section-hdr { background: rgba(124,58,237,0.08) !important; color: #4c1d95; border-color: rgba(124,58,237,0.22); }
  .sec-actions .section-body { border-color: rgba(124,58,237,0.2); }
  .sec-actions .row { border-color: rgba(124,58,237,0.1); }

  /* Financial */
  .sec-financial .section-hdr { background: rgba(22,163,74,0.10) !important; color: #14532d; border-color: rgba(22,163,74,0.25); }
  .sec-financial .section-body { border-color: rgba(22,163,74,0.2); }
  .sec-financial .row { border-color: rgba(22,163,74,0.08); }

  /* Operational */
  .sec-operational .section-hdr { background: rgba(245,158,11,0.10) !important; color: #78350f; border-color: rgba(245,158,11,0.3); }
  .sec-operational .section-body { border-color: rgba(245,158,11,0.25); }
  .sec-operational .row { border-color: rgba(245,158,11,0.1); }

  /* Strategic (non-financial) */
  .sec-strategic .section-hdr { background: rgba(184,134,11,0.08) !important; color: #8a6508; border-color: rgba(184,134,11,0.22); }
  .sec-strategic .section-body { border-color: rgba(232,184,75,0.2); }
  .sec-strategic .row { border-color: rgba(232,184,75,0.08); }

  /* Opportunities */
  .sec-opportunities .section-hdr { background: rgba(5,150,105,0.08) !important; color: #064e3b; border-color: rgba(5,150,105,0.22); }
  .sec-opportunities .section-body { border-color: rgba(5,150,105,0.2); }
  .sec-opportunities .row { border-color: rgba(5,150,105,0.08); }

  /* Biases */
  .sec-biases .section-hdr { background: rgba(245,158,11,0.10) !important; color: #78350f; border-color: rgba(245,158,11,0.28); }
  .sec-biases .section-body { border-color: rgba(245,158,11,0.22); }
  .sec-biases .row { border-color: rgba(245,158,11,0.08); }

  /* Recommendation */
  .sec-recommendation .section-hdr { background: rgba(184,134,11,0.10) !important; color: #8a6508; border-color: rgba(184,134,11,0.28); }
  .sec-recommendation .section-body { border-color: rgba(232,184,75,0.18); }
  .sec-recommendation .row { border-color: rgba(232,184,75,0.08); font-size: 10pt; line-height: 1.75; color: #334155; }

  /* Tags */
  .tag {
    display: inline-block; font-size: 7.5pt; font-weight: 700;
    padding: 1px 7px; border-radius: 999px; text-transform: capitalize;
  }
  .tag-critical { background: rgba(168,41,42,0.12) !important; color: #a8292a; }
  .tag-high     { background: rgba(179,92,16,0.12) !important; color: #b35c10; }
  .tag-medium   { background: rgba(184,134,11,0.10) !important; color: #8a6508; }
  .tag-low      { background: rgba(15,23,42,0.07)  !important; color: #5D6B82; }
  .tag-manual   { background: rgba(15,23,42,0.07)  !important; color: #5D6B82; }
  .tag-ai       { background: rgba(124,58,237,0.10) !important; color: #7c3aed; }

  /* Conflict pair */
  .conflict-pair { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-top: 8px; }
  .conflict-side { padding: 8px 10px; border-radius: 6px; font-size: 9pt; }
  .cs-a { background: rgba(232,184,75,0.06) !important; border: 1px solid rgba(232,184,75,0.14); }
  .cs-b { background: rgba(220,38,38,0.05) !important; border: 1px solid rgba(220,38,38,0.14); }
  .ca-a { font-size: 7.5pt; font-weight: 700; color: #8a6508; margin-bottom: 3px; }
  .ca-b { font-size: 7.5pt; font-weight: 700; color: #a8292a; margin-bottom: 3px; }

  /* In-flow document footer — always at the natural end of content, never overlapping */
  .doc-footer {
    margin-top: 36px;
    padding-top: 10px;
    border-top: 1px solid #e2e8f0;
    font-size: 7.5pt; color: #94a3b8;
    display: flex; justify-content: space-between; align-items: center;
    page-break-inside: avoid; break-inside: avoid;
  }
  .doc-footer-ad {
    font-size: 7pt; font-weight: 700; color: #94a3b8;
    letter-spacing: 0.04em; text-align: center;
  }

  /* ── Topic banner ── */
  .topic-banner {
    display: flex; align-items: flex-start; gap: 12px;
    background: rgba(232,184,75,0.06) !important;
    border-left: 3px solid #b8860b;
    border-radius: 0 4px 4px 0;
    padding: 10px 14px;
    margin-bottom: 22px;
    page-break-inside: avoid; break-inside: avoid;
  }
  .topic-banner-label {
    font-size: 7pt; font-weight: 700; letter-spacing: 0.09em;
    text-transform: uppercase; color: #8892a4;
    white-space: nowrap; padding-top: 2px;
  }
  .topic-banner-text {
    font-size: 11pt; font-weight: 800; color: #111827; line-height: 1.35;
  }

  /* ── Chat ── */
  .msg { margin-bottom: 12px; page-break-inside: avoid; break-inside: avoid; }
  .msg-user { display: flex; flex-direction: column; align-items: flex-end; }
  .msg-user .bubble { background: #171c26 !important; color: #e8ecf2; border: 1px solid #1f2535; border-radius: 14px 14px 2px 14px; padding: 9px 13px; max-width: 78%; font-size: 10pt; }
  .msg-user .meta { font-size: 7pt; color: #94a3b8; margin-top: 2px; text-align: right; }
  .msg-agent { display: flex; gap: 10px; align-items: flex-start; max-width: 84%; }
  .agent-icon { width: 26px; height: 26px; border-radius: 7px; display: flex; align-items: center; justify-content: center; font-size: 12pt; flex-shrink: 0; }
  .agent-name { font-size: 7.5pt; font-weight: 700; margin-bottom: 2px; }
  .agent-bubble { border-radius: 2px 14px 14px 14px; padding: 9px 13px; font-size: 10pt; }
  .role-strategic_analyst .agent-name { color: #8a6508; }
  .role-strategic_analyst .agent-bubble { background: rgba(232,184,75,0.07) !important; border: 1px solid rgba(232,184,75,0.15); }
  .role-devils_advocate .agent-name { color: #a8292a; }
  .role-devils_advocate .agent-bubble { background: rgba(220,38,38,0.07) !important; border: 1px solid rgba(220,38,38,0.15); }
  .role-innovation_scout .agent-name { color: #065f46; }
  .role-innovation_scout .agent-bubble { background: rgba(16,185,129,0.07) !important; border: 1px solid rgba(16,185,129,0.18); }
  .role-other .agent-name { color: #5D6B82; }
  .role-other .agent-bubble { background: #f1f5f9 !important; border: 1px solid #1f2535; }

  /* ── Board Brief ── */
  .bb-score-ring { display: flex; align-items: center; gap: 18px; margin-bottom: 22px; page-break-inside: avoid; break-inside: avoid; }
  .bb-score-info { flex: 1; }
  .bb-score-title { font-size: 20pt; font-weight: 900; color: #111827; }
  .bb-score-sub { font-size: 9pt; color: #64748b; margin-top: 2px; margin-bottom: 6px; }
  .bb-score-rationale { font-size: 9.5pt; color: #5D6B82; line-height: 1.6; }
  .bb-section { margin-bottom: 20px; }
  .bb-section-title {
    font-size: 8pt; font-weight: 800; text-transform: uppercase; letter-spacing: 0.08em;
    color: #8892a4; margin-bottom: 8px; padding-bottom: 5px; border-bottom: 1.5px solid #b8860b;
    page-break-after: avoid; break-after: avoid;
  }
  .bb-row { display: flex; align-items: flex-start; gap: 10px; padding: 7px 0; border-bottom: 1px solid #f1f5f9; page-break-inside: avoid; break-inside: avoid; }
  .bb-num { font-size: 8.5pt; font-weight: 700; color: #94a3b8; min-width: 18px; flex-shrink: 0; margin-top: 1px; }
  .bb-text { font-size: 10pt; color: #111827; line-height: 1.5; flex: 1; }
  .bb-badge { font-size: 7pt; font-weight: 700; padding: 1px 7px; border-radius: 999px; flex-shrink: 0; margin-top: 2px; text-transform: capitalize; }
  .bb-priority-critical { background: rgba(168,41,42,0.12) !important; color: #a8292a; }
  .bb-priority-high     { background: rgba(179,92,16,0.12) !important; color: #b35c10; }
  .bb-priority-medium   { background: rgba(184,134,11,0.10) !important; color: #8a6508; }
  .bb-priority-low      { background: rgba(15,23,42,0.07)  !important; color: #5D6B82; }
  .bb-sev-critical { background: rgba(168,41,42,0.12) !important; color: #a8292a; }
  .bb-sev-high     { background: rgba(179,92,16,0.12) !important; color: #b35c10; }
  .bb-sev-medium   { background: rgba(184,134,11,0.10) !important; color: #8a6508; }
  .bb-sev-low      { background: rgba(15,23,42,0.07)  !important; color: #5D6B82; }
`;

// ─── Full document wrapper ────────────────────────────────────────────────────

function wrapDocument(bodyHtml: string, title: string): string {
  return `<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>${escapeHtml(title)}</title>
  <style>${BASE_STYLES}</style>
</head>
<body>
  <div class="print-toolbar">
    <span class="print-toolbar-title">${escapeHtml(title)}</span>
    <a class="btn-close" href="javascript:window.close()">&#x2190; Back</a>
    <button class="btn-print" onclick="window.print()">&#x1F5A8;&nbsp; Print / Save PDF</button>
  </div>
  ${bodyHtml}
  <script>
    // Close button: prefer history.back() so PWA/installed apps return to the previous view.
    // Falls back to window.close() if there is no history entry to go back to.
    document.querySelector('.btn-close').addEventListener('click', function(e) {
      e.preventDefault();
      if (window.history.length > 1) { window.history.back(); }
      else { window.close(); }
    });
  </script>
</body>
</html>`;
}

// ─── Print Window ─────────────────────────────────────────────────────────────

function openPrintWindow(bodyHtml: string, title: string) {
  const html = wrapDocument(bodyHtml, title);

  // Prefer a new tab (full browser chrome, Back button works natively).
  // In PWA/standalone mode window.open may return null; fall back to iframe.
  const win = window.open('', '_blank');
  if (win) {
    win.document.open();
    win.document.write(html);
    win.document.close();
    return;
  }

  // PWA fallback: render into a full-viewport iframe injected into the current page.
  // The "Back" button in the toolbar calls history.back() which dismisses the iframe overlay.
  const overlay = document.createElement('div');
  overlay.id = 'pdf-preview-overlay';
  overlay.style.cssText = 'position:fixed;inset:0;z-index:99999;background:#fff;';

  const iframe = document.createElement('iframe');
  iframe.style.cssText = 'width:100%;height:100%;border:0;';
  overlay.appendChild(iframe);
  document.body.appendChild(overlay);

  // Push a history entry so the Back gesture / button removes the overlay.
  history.pushState({ pdfPreview: true }, '', location.href);
  const popHandler = () => {
    try { document.body.removeChild(overlay); } catch {}
    window.removeEventListener('popstate', popHandler);
  };
  window.addEventListener('popstate', popHandler);

  const doc = iframe.contentDocument!;
  doc.open();
  doc.write(html);
  doc.close();

  // Wire the close button inside the iframe to pop history instead of closing.
  const wireClose = () => {
    const btn = iframe.contentDocument?.querySelector('.btn-close') as HTMLElement | null;
    if (btn) {
      btn.addEventListener('click', (e) => {
        e.preventDefault();
        history.back();
      });
    }
  };
  if (iframe.contentDocument?.readyState === 'complete') wireClose();
  else iframe.onload = wireClose;
}

function pageChrome(_subtitle: string): string {
  return '';
}

// ─── Chat Export ─────────────────────────────────────────────────────────────

function topicBannerHtml(topic: string | undefined): string {
  if (!topic?.trim()) return '';
  return `<div class="topic-banner">
    <span class="topic-banner-label">Topic</span>
    <span class="topic-banner-text">${escapeHtml(topic)}</span>
  </div>`;
}

export function exportChatToPDF(messages: ChatMessageExport[], workspaceName: string, topic?: string, workspaceId?: string) {
  const ICONS: Record<string, string> = {
    strategic_analyst: '&#x1F4CA;',
    devils_advocate: '&#x2694;&#xFE0F;',
    innovation_scout: '&#x1F52D;',
  };
  const rows = messages.map(m => {
    if (m.role === 'user') return `
      <div class="msg"><div class="msg-user">
        <div class="bubble">${escapeHtml(m.content)}</div>
        <div class="meta">${formatDate(m.created_at)}</div>
      </div></div>`;
    const role = m.agent_role || 'other';
    const charts = m.chart_data ? svgConsensusCharts(m.chart_data) : '';
    const figures = m.figures ? svgAgentFigures(m.figures) : '';
    return `
      <div class="msg"><div class="msg-agent role-${role}">
        <div class="agent-icon">${ICONS[role] || '&#x1F916;'}</div>
        <div>
          <div class="agent-name">${escapeHtml(m.agent_name || 'AI Agent')}</div>
          <div class="agent-bubble">${escapeHtml(m.content)}</div>
          ${charts}${figures}
        </div>
      </div></div>`;
  }).join('');

  const html = `<div class="print-root">
    ${pageChrome('Multiplayer AI')}
    <div class="doc-header">
      <div class="doc-header-top">
        <div>
          <div class="brand">Poddle · Multiplayer AI</div>
          <div class="title">${escapeHtml(workspaceName)}</div>
          <div class="subtitle">Discussion Transcript</div>
        </div>
        <div class="meta-right">Exported ${formatDate(new Date().toISOString())}<br>${messages.length} message${messages.length !== 1 ? 's' : ''}</div>
      </div>
    </div>
    ${topicBannerHtml(topic)}
    ${rows}
    <div class="doc-footer">
      <span>Poddle, Inc. — AI-Powered Strategic Intelligence</span>
      <span class="doc-footer-ad">poddleme.com</span>
      <span>Confidential · ${formatDate(new Date().toISOString())}</span>
    </div>
  </div>`;
  logExport('chat', workspaceName, workspaceId);
  openPrintWindow(html, `${workspaceName} — Discussion`);
}

// ─── War Room Full Export ─────────────────────────────────────────────────────

export function exportWarRoomToPDF(data: WarRoomExport) {
  const sc = scoreColor(data.decisionHealthScore);
  const sl = scoreLabel(data.decisionHealthScore);

  function subScoreBar(label: string, score: number | null | undefined): string {
    if (score == null) return '';
    const c = scoreColor(score);
    const W = 80, H = 6, r = 3;
    const fillW = Math.max(r * 2, (score / 100) * W);
    return `<div style="display:flex;align-items:center;gap:6px;margin-top:4px;">
      <span style="font-size:7pt;color:#94a3b8;min-width:90px;">${label}</span>
      <svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg">
        <rect x="0" y="0" width="${W}" height="${H}" rx="${r}" fill="rgba(255,255,255,0.12)"/>
        <rect x="0" y="0" width="${fillW.toFixed(1)}" height="${H}" rx="${r}" fill="${c}"/>
      </svg>
      <span style="font-size:7.5pt;font-weight:800;color:${c};">${score}</span>
    </div>`;
  }

  function velocityBadge(v: string | null | undefined): string {
    if (!v) return '';
    const map: Record<string, { color: string; bg: string }> = {
      fast:     { color: '#15803d', bg: 'rgba(22,163,74,0.15)' },
      moderate: { color: '#b35c10', bg: 'rgba(179,92,16,0.15)' },
      stalling: { color: '#a8292a', bg: 'rgba(168,41,42,0.15)' },
    };
    const s = map[v.toLowerCase()] || map.moderate;
    return `<span style="display:inline-block;font-size:7pt;font-weight:700;padding:2px 8px;border-radius:999px;background:${s.bg};color:${s.color};margin-left:6px;">${v.charAt(0).toUpperCase() + v.slice(1)} Velocity</span>`;
  }

  function trajectoryBadge(t: string | null | undefined): string {
    if (!t) return '';
    const map: Record<string, { color: string; bg: string }> = {
      rising:  { color: '#15803d', bg: 'rgba(22,163,74,0.15)' },
      flat:    { color: '#b35c10', bg: 'rgba(179,92,16,0.15)' },
      falling: { color: '#a8292a', bg: 'rgba(168,41,42,0.15)' },
    };
    const s = map[t.toLowerCase()] || map.flat;
    const label = t === 'rising' ? 'Confidence Rising' : t === 'falling' ? 'Confidence Falling' : 'Confidence Flat';
    return `<span style="display:inline-block;font-size:7pt;font-weight:700;padding:2px 8px;border-radius:999px;background:${s.bg};color:${s.color};margin-left:6px;">${label}</span>`;
  }

  function sec(cls: string, title: string, icon: string, rows: string[]): string {
    if (!rows.length) return '';
    return `<div class="section sec-${cls}">
      <div class="section-hdr">${icon}&nbsp; ${title}</div>
      <div class="section-body">${rows.join('')}</div>
    </div>`;
  }

  const confColor = (c: string) => c === 'high' ? '#1e7a52' : c === 'low' ? '#a8292a' : '#b35c10';
  const confBg    = (c: string) => c === 'high' ? 'rgba(22,163,74,0.12)' : c === 'low' ? 'rgba(220,38,38,0.12)' : 'rgba(245,158,11,0.12)';
  const opStatusColor = (s: string) => ['clear','on-track'].includes(s) ? '#1e7a52' : s === 'at-risk' ? '#a8292a' : '#b35c10';
  const opStatusBg    = (s: string) => ['clear','on-track'].includes(s) ? 'rgba(22,163,74,0.12)' : s === 'at-risk' ? 'rgba(220,38,38,0.12)' : 'rgba(245,158,11,0.12)';
  const sigColor = (s: string) => s === 'positive' ? '#1e7a52' : s === 'negative' ? '#a8292a' : '#5D6B82';
  const sigBg    = (s: string) => s === 'positive' ? 'rgba(22,163,74,0.12)' : s === 'negative' ? 'rgba(220,38,38,0.12)' : 'rgba(100,116,139,0.12)';

  // ── Consensus with SVG bars ──
  const consensusRows = data.consensusPoints.map((pt, i) => {
    const conf = Math.max(0, Math.min(100, pt.confidence || 0));
    const c = conf >= 80 ? '#1e7a52' : conf >= 60 ? '#84cc16' : '#b35c10';
    return `<div class="row">
      <div style="display:flex;align-items:flex-start;gap:10px;">
        <span style="font-size:8pt;font-weight:700;color:#14532d;min-width:16px;flex-shrink:0;">${i + 1}.</span>
        <div style="flex:1;">
          <div style="margin-bottom:6px;">${escapeHtml(pt.text)}</div>
          <div style="display:flex;align-items:center;gap:8px;">
            ${svgConsensusBar(conf, c)}
            <span style="font-size:7.5pt;font-weight:700;color:${c};">${conf}%</span>
            <span style="font-size:7.5pt;color:#64748b;">${pt.source_count} agreed</span>
          </div>
        </div>
      </div>
    </div>`;
  });

  // ── Conflict zones with SVG tension bars ──
  const conflictRows = data.conflictZones.map(z => {
    const lvl = Math.max(0, Math.min(100, z.tension_level || 0));
    return `<div class="row">
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">
        <strong style="font-size:9.5pt;">${escapeHtml(z.topic)}</strong>
        ${svgTensionBar(lvl)}
        <span style="font-size:7.5pt;font-weight:700;color:${lvl >= 70 ? '#a8292a' : lvl >= 45 ? '#b35c10' : '#8a6508'};">${lvl}/100</span>
      </div>
      <div class="conflict-pair">
        <div class="conflict-side cs-a">
          <div class="ca-a">${escapeHtml(formatAgentName(z.agent_a))}</div>
          <div style="font-size:9pt;">${escapeHtml(z.position_a)}</div>
        </div>
        <div class="conflict-side cs-b">
          <div class="ca-b">${escapeHtml(formatAgentName(z.agent_b))}</div>
          <div style="font-size:9pt;">${escapeHtml(z.position_b)}</div>
        </div>
      </div>
    </div>`;
  });

  // ── Open questions ──
  const questionRows = data.openQuestions.map(q => `
    <div class="row" style="display:flex;align-items:flex-start;gap:10px;">
      <span class="tag tag-${q.urgency?.toLowerCase()}">${escapeHtml(q.urgency)}</span>
      <span>${escapeHtml(q.question)}</span>
    </div>`);

  // ── Risk signals — list + SVG matrix ──
  const riskRows = data.riskSignals.length > 0 ? [
    // SVG matrix first
    `<div class="row" style="padding:16px 14px 8px;">
      <div style="font-size:7.5pt;font-weight:700;color:#64748b;text-transform:uppercase;letter-spacing:0.07em;margin-bottom:10px;">Severity &times; Category Matrix</div>
      ${svgRiskMatrix(data.riskSignals)}
    </div>`,
    // Then numbered list
    ...data.riskSignals.map((r, i) => `
      <div class="row" style="display:flex;align-items:flex-start;gap:10px;">
        <div style="width:20px;height:20px;border-radius:50%;background:${severityColor(r.severity)};flex-shrink:0;display:flex;align-items:center;justify-content:center;">
          <span style="font-size:8pt;font-weight:900;color:#fff;">${i + 1}</span>
        </div>
        <div style="flex:1;">
          <div style="display:flex;align-items:center;gap:6px;margin-bottom:3px;">
            <span class="tag tag-${r.severity?.toLowerCase()}">${escapeHtml(r.severity)}</span>
            <span style="font-size:7.5pt;color:#64748b;text-transform:capitalize;">${escapeHtml(r.category)}</span>
          </div>
          <span style="font-size:9.5pt;">${escapeHtml(r.signal)}</span>
        </div>
      </div>`)
  ] : [];

  // ── Blind spots ──
  const blindRows = data.blindSpots.map(bs => `
    <div class="row">
      <div style="font-size:10pt;font-weight:700;color:#0c4a6e;margin-bottom:2px;">${escapeHtml(bs.area)}</div>
      <div style="font-size:9.5pt;color:#5D6B82;">${escapeHtml(bs.description)}</div>
    </div>`);

  // ── Action items ──
  const actionRows = (data.actionItems || []).map((a, i) => `
    <div class="row" style="display:flex;align-items:flex-start;gap:10px;">
      <span style="font-size:8.5pt;font-weight:700;color:#7c3aed;min-width:18px;flex-shrink:0;">${i + 1}.</span>
      <div style="flex:1;">
        <div style="font-size:9.5pt;${a.status === 'done' ? 'text-decoration:line-through;color:#94a3b8;' : 'color:#111827;'}margin-bottom:4px;">${escapeHtml(a.text)}</div>
        <div style="display:flex;gap:5px;align-items:center;flex-wrap:wrap;">
          <span class="tag tag-${a.priority?.toLowerCase()}">${escapeHtml(a.priority)}</span>
          <span class="tag" style="background:rgba(15,23,42,0.07)!important;color:#5D6B82;text-transform:capitalize;">${a.status.replace('_', ' ')}</span>
          ${a.source === 'ai' ? '<span class="tag" style="background:rgba(124,58,237,0.10)!important;color:#7c3aed;">AI</span>' : ''}
          ${a.source_area ? `<span class="tag" style="background:rgba(184,134,11,0.10)!important;color:#8a6508;text-transform:uppercase;letter-spacing:0.04em;font-size:7pt;">${escapeHtml(a.source_area)}</span>` : ''}
        </div>
      </div>
    </div>`);

  // ── Financial metrics ──
  const financialRows = (data.financialMetrics || []).map(m => `
    <div class="row" style="display:flex;align-items:flex-start;gap:10px;">
      <div style="flex:1;">
        <div style="display:flex;align-items:center;gap:6px;margin-bottom:3px;">
          <span style="font-size:9.5pt;font-weight:700;color:#14532d;">${escapeHtml(m.metric)}</span>
          <span style="font-size:7pt;font-weight:700;padding:1px 7px;border-radius:999px;background:${confBg(m.confidence?.toLowerCase())};color:${confColor(m.confidence?.toLowerCase())};">${escapeHtml(m.confidence)} confidence</span>
        </div>
        <div style="font-size:9.5pt;font-weight:600;color:#111827;margin-bottom:2px;">${escapeHtml(m.value)}</div>
        <div style="font-size:8.5pt;color:#64748b;">${escapeHtml(m.note)}</div>
      </div>
    </div>`);

  // ── Operational metrics ──
  const operationalRows = (data.operationalMetrics || []).map(m => `
    <div class="row" style="display:flex;align-items:flex-start;gap:10px;">
      <div style="flex:1;">
        <div style="display:flex;align-items:center;gap:6px;margin-bottom:3px;">
          <span style="font-size:9.5pt;font-weight:700;color:#78350f;">${escapeHtml(m.metric)}</span>
          <span style="font-size:7pt;font-weight:700;padding:1px 7px;border-radius:999px;text-transform:capitalize;background:${opStatusBg(m.status?.toLowerCase())};color:${opStatusColor(m.status?.toLowerCase())};">${escapeHtml(m.status?.replace('-', ' ') || '')}</span>
        </div>
        <div style="font-size:8.5pt;color:#64748b;">${escapeHtml(m.note)}</div>
      </div>
    </div>`);

  // ── Non-financial / strategic metrics ──
  const strategicRows = (data.nonFinancialMetrics || []).map(m => `
    <div class="row" style="display:flex;align-items:flex-start;gap:10px;">
      <div style="flex:1;">
        <div style="display:flex;align-items:center;gap:6px;margin-bottom:3px;">
          <span style="font-size:9.5pt;font-weight:700;color:#8a6508;">${escapeHtml(m.metric)}</span>
          <span style="font-size:7pt;font-weight:700;padding:1px 7px;border-radius:999px;text-transform:capitalize;background:${sigBg(m.signal?.toLowerCase())};color:${sigColor(m.signal?.toLowerCase())};">${escapeHtml(m.signal)}</span>
        </div>
        <div style="font-size:8.5pt;color:#64748b;">${escapeHtml(m.note)}</div>
      </div>
    </div>`);

  // ── Opportunity signals ──
  const opportunityRows = (data.opportunitySignals || []).map((o, i) => `
    <div class="row">
      <div style="display:flex;align-items:flex-start;gap:10px;">
        <span style="font-size:8pt;font-weight:700;color:#064e3b;min-width:16px;flex-shrink:0;">${i + 1}.</span>
        <div style="flex:1;">
          <div style="display:flex;align-items:center;gap:6px;margin-bottom:3px;">
            <span style="font-size:9.5pt;font-weight:700;color:#064e3b;">${escapeHtml(o.title)}</span>
            <span style="font-size:7pt;font-weight:700;padding:1px 7px;border-radius:999px;background:${confBg(o.confidence?.toLowerCase())};color:${confColor(o.confidence?.toLowerCase())};">${escapeHtml(o.confidence)}</span>
          </div>
          <div style="font-size:9.5pt;color:#111827;margin-bottom:2px;">${escapeHtml(o.description)}</div>
          <div style="font-size:8pt;color:#94a3b8;font-style:italic;">Source: ${escapeHtml(o.source)}</div>
        </div>
      </div>
    </div>`);

  // ── Cognitive bias flags ──
  const biasRows = (data.cognitiveBiasFlags || []).map(f => `
    <div class="row">
      <div style="font-size:10pt;font-weight:800;color:#78350f;margin-bottom:3px;">${escapeHtml(f.bias_name)}</div>
      <div style="font-size:9pt;color:#5D6B82;margin-bottom:6px;">${escapeHtml(f.explanation)}</div>
      <div style="background:rgba(245,158,11,0.08);border:1px solid rgba(245,158,11,0.2);border-radius:6px;padding:8px 10px;">
        <div style="font-size:7.5pt;font-weight:700;color:#b35c10;margin-bottom:2px;">Counter-question</div>
        <div style="font-size:8.5pt;color:#78350f;font-style:italic;">"${escapeHtml(f.counter_question)}"</div>
      </div>
    </div>`);

  const html = `<div class="print-root">
    ${pageChrome('War Room')}
    <div class="doc-header">
      <div class="doc-header-top">
        <div>
          <div class="brand">Poddle · War Room Intelligence</div>
          <div class="title">${escapeHtml(data.workspaceName)}</div>
          <div class="subtitle">Strategic Intelligence Report</div>
        </div>
        <div class="meta-right">
          Generated ${formatDate(data.generatedAt)}<br>
          Based on full War Room session
        </div>
      </div>
    </div>
    ${topicBannerHtml(data.topic)}

    <div class="score-block">
      ${svgScoreRing(data.decisionHealthScore)}
      <div style="flex:1;">
        <div class="score-label" style="color:${sc};">${sl} Team</div>
        <div class="score-sub">Decision Health Score: ${data.decisionHealthScore} / 100</div>
        <div class="score-rationale">${escapeHtml(data.healthRationale || 'AI-assessed clarity, risk coverage, and strategic alignment.')}</div>
        <div style="margin-top:8px;">
          ${subScoreBar('Financial Clarity', data.financialScore)}
          ${subScoreBar('Operational Readiness', data.operationalScore)}
          ${subScoreBar('Strategic Alignment', data.alignmentScore)}
        </div>
        ${data.decisionVelocity || data.confidenceTrajectory ? `<div style="margin-top:8px;">${velocityBadge(data.decisionVelocity)}${trajectoryBadge(data.confidenceTrajectory)}</div>` : ''}
      </div>
    </div>

    ${data.recommendation ? sec('recommendation', 'Strategic Recommendation', '&#x2728;', [`<div class="row">${escapeHtml(data.recommendation)}</div>`]) : ''}
    ${sec('consensus',    'Team Consensus',          '&#x2713;',  consensusRows)}
    ${sec('conflicts',    'Strategic Conflict Zones', '&#x26A1;',  conflictRows)}
    ${sec('questions',    'Open Questions',           '?',         questionRows)}
    ${sec('risks',        'Risk Signals',             '&#x26A0;',  riskRows)}
    ${sec('blindspots',   'Blind Spots',              '&#x25CE;',  blindRows)}
    ${sec('financial',    'Financial Metrics',        '&#x24C2;',  financialRows)}
    ${sec('operational',  'Operational Readiness',   '&#x2699;',  operationalRows)}
    ${sec('strategic',    'Strategic & Non-Financial','&#x25A0;',  strategicRows)}
    ${sec('opportunities','Opportunity Signals',      '&#x2B50;',  opportunityRows)}
    ${sec('biases',       'Cognitive Bias Flags',     '&#x26A0;',  biasRows)}
    ${actionRows.length ? sec('actions', 'Action Items', '&#x25B6;', actionRows) : ''}

    <div class="doc-footer">
      <span>Poddle, Inc. — AI-Powered Strategic Intelligence</span>
      <span class="doc-footer-ad">poddleme.com</span>
      <span>Confidential · Exported ${formatDate(new Date().toISOString())}</span>
    </div>
  </div>`;

  logExport('war_room', data.workspaceName, data.workspaceId);
  openPrintWindow(html, `${data.workspaceName} — War Room Report`);
}

// ─── Board Brief Export ───────────────────────────────────────────────────────

export function exportBoardBriefToPDF(data: BoardBriefExport) {
  const sc = scoreColor(data.decisionHealthScore);
  const sl = scoreLabel(data.decisionHealthScore);
  const pendingActions = data.actionItems
    .filter(a => a.status !== 'done')
    .sort((a, b) => {
      const o = ['critical', 'high', 'medium', 'low'];
      return o.indexOf(a.priority?.toLowerCase()) - o.indexOf(b.priority?.toLowerCase());
    })
    .slice(0, 5);

  function bbSubScore(label: string, score: number | null | undefined): string {
    if (score == null) return '';
    const c = scoreColor(score);
    const W = 70, H = 5, r = 2;
    const fillW = Math.max(r * 2, (score / 100) * W);
    return `<div style="display:flex;align-items:center;gap:6px;margin-top:3px;">
      <span style="font-size:7pt;color:#94a3b8;min-width:85px;">${label}</span>
      <svg width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" xmlns="http://www.w3.org/2000/svg">
        <rect x="0" y="0" width="${W}" height="${H}" rx="${r}" fill="#1f2535"/>
        <rect x="0" y="0" width="${fillW.toFixed(1)}" height="${H}" rx="${r}" fill="${c}"/>
      </svg>
      <span style="font-size:7.5pt;font-weight:800;color:${c};">${score}</span>
    </div>`;
  }

  const confColor = (c: string) => c === 'high' ? '#1e7a52' : c === 'low' ? '#a8292a' : '#b35c10';
  const confBg    = (c: string) => c === 'high' ? 'rgba(22,163,74,0.12)' : c === 'low' ? 'rgba(220,38,38,0.12)' : 'rgba(245,158,11,0.12)';

  const consensusHtml = data.consensusPoints.slice(0, 3).map((p, i) => {
    const conf = Math.max(0, Math.min(100, p.confidence || 0));
    const c = conf >= 80 ? '#1e7a52' : conf >= 60 ? '#84cc16' : '#b35c10';
    return `<div class="bb-row">
      <span class="bb-num">${i + 1}.</span>
      <div style="flex:1;">
        <div class="bb-text" style="margin-bottom:5px;">${escapeHtml(p.text)}</div>
        <div style="display:flex;align-items:center;gap:8px;">
          ${svgConsensusBar(conf, c)}
          <span style="font-size:7.5pt;font-weight:700;color:${c};">${conf}%</span>
        </div>
      </div>
    </div>`;
  }).join('');

  const risksHtml = data.riskSignals.slice(0, 3).map((r, i) => `
    <div class="bb-row">
      <span class="bb-num">${i + 1}.</span>
      <div class="bb-text">${escapeHtml(r.signal)}</div>
      <span class="bb-badge bb-sev-${r.severity?.toLowerCase()}">${escapeHtml(r.severity)}</span>
    </div>`).join('');

  const actionsHtml = pendingActions.map((a, i) => `
    <div class="bb-row">
      <span class="bb-num">${i + 1}.</span>
      <div class="bb-text">${escapeHtml(a.text)}</div>
      <div style="display:flex;gap:4px;align-items:center;flex-shrink:0;">
        ${a.source_area ? `<span class="bb-badge" style="background:rgba(184,134,11,0.10)!important;color:#8a6508;text-transform:uppercase;letter-spacing:0.04em;">${escapeHtml(a.source_area)}</span>` : ''}
        <span class="bb-badge bb-priority-${a.priority?.toLowerCase()}">${escapeHtml(a.priority)}</span>
      </div>
    </div>`).join('');

  const opportunitiesHtml = (data.opportunitySignals || []).slice(0, 3).map((o, i) => `
    <div class="bb-row">
      <span class="bb-num">${i + 1}.</span>
      <div style="flex:1;">
        <div style="font-size:9.5pt;font-weight:700;color:#064e3b;margin-bottom:2px;">${escapeHtml(o.title)}</div>
        <div class="bb-text" style="font-size:9pt;">${escapeHtml(o.description)}</div>
      </div>
      <span style="font-size:7pt;font-weight:700;padding:1px 7px;border-radius:999px;flex-shrink:0;background:${confBg(o.confidence?.toLowerCase())};color:${confColor(o.confidence?.toLowerCase())};">${escapeHtml(o.confidence)}</span>
    </div>`).join('');

  const runBadge = data.synthesisRunNumber ? `<span style="font-size:7.5pt;font-weight:600;color:#94a3b8;margin-left:10px;">Run #${data.synthesisRunNumber}</span>` : '';

  const html = `<div class="print-root">
    ${pageChrome('Board Brief')}
    <div class="doc-header">
      <div class="doc-header-top">
        <div>
          <div class="brand">Poddle · War Room</div>
          <div class="title">${escapeHtml(data.workspaceName)}</div>
          <div class="subtitle">Board-Ready Brief</div>
        </div>
        <div class="meta-right">
          Generated ${formatDate(data.generatedAt)}<br>
          ${formatDate(new Date().toISOString())} export
        </div>
      </div>
    </div>
    ${topicBannerHtml(data.topic)}

    <div class="bb-score-ring">
      ${svgScoreRing(data.decisionHealthScore)}
      <div class="bb-score-info">
        <div class="bb-score-title" style="color:${sc};">${sl} Team ${runBadge}</div>
        <div class="bb-score-sub">Decision Health Score: ${data.decisionHealthScore} / 100</div>
        <div class="bb-score-rationale">${escapeHtml(data.healthRationale || 'AI-assessed strategic clarity and decision quality.')}</div>
        <div style="margin-top:6px;">
          ${bbSubScore('Financial Clarity', data.financialScore)}
          ${bbSubScore('Operational Readiness', data.operationalScore)}
          ${bbSubScore('Strategic Alignment', data.alignmentScore)}
        </div>
      </div>
    </div>

    ${data.consensusPoints.length > 0 ? `
    <div class="bb-section">
      <div class="bb-section-title">Team Consensus</div>
      ${consensusHtml}
    </div>` : ''}

    ${data.riskSignals.length > 0 ? `
    <div class="bb-section">
      <div class="bb-section-title">Key Risks</div>
      ${risksHtml}
    </div>` : ''}

    ${opportunitiesHtml ? `
    <div class="bb-section">
      <div class="bb-section-title">Opportunity Signals</div>
      ${opportunitiesHtml}
    </div>` : ''}

    ${pendingActions.length > 0 ? `
    <div class="bb-section">
      <div class="bb-section-title">Priority Actions</div>
      ${actionsHtml}
    </div>` : ''}

    <div class="doc-footer">
      <span>Poddle, Inc. — AI-Powered Strategic Intelligence</span>
      <span class="doc-footer-ad">poddleme.com</span>
      <span>Confidential · ${formatDate(new Date().toISOString())}</span>
    </div>
  </div>`;

  logExport('board_brief', data.workspaceName, data.workspaceId);
  openPrintWindow(html, `${data.workspaceName} — Board Brief`);
}

// ─── Decision Trail / Evidence Export ─────────────────────────────────────────
// Designed so someone with zero prior context can open this PDF and answer:
// what was considered, what was decided, by whom, why, on what evidence, how
// strong that evidence was, what AI first recommended, what humans changed
// or challenged, what's still unresolved, and what happened after.

export interface EvidenceExportItem {
  claim_code: string;
  agent_name: string;
  statement: string;
  claim_type: string;
  evidence_classification?: string | null;
  verification_status?: string | null;
  verified_at?: string | null;
  verified_by_name?: string | null;
  source_name?: string | null;
  source_reference?: string | null;
  confidence: number;
  ai_confidence_score?: number | null;
  freshness: 'current' | 'aging' | 'stale';
  daysSinceVerified: number;
  last_reviewed_at?: string | null;
  verification_method?: string | null;
}

export interface EvidenceVersionExportItem {
  claim_code: string;
  version_number: number;
  previous_statement: string | null;
  updated_statement: string | null;
  previous_classification: string | null;
  updated_classification: string | null;
  previous_verification_status: string | null;
  updated_verification_status: string | null;
  source_reference: string | null;
  reason_for_modification: string;
  modified_by_name: string | null;
  modified_at: string;
}

export interface SnapshotExportItem {
  decision_question: string | null;
  decision_status: string | null;
  evidence_snapshot?: unknown;
  verified_facts?: unknown;
  reported_facts?: unknown;
  assumptions?: unknown;
  ai_inferences?: unknown;
  outstanding_uncertainties?: unknown;
  human_approvals?: unknown;
  snapshot_timestamp: string;
  created_by_name: string | null;
  verified_facts_count: number;
  reported_facts_count: number;
  assumptions_count: number;
  ai_inferences_count: number;
  ai_recommendation: string | null;
}

export interface TrailEventExportItem {
  event_type: string;
  label: string;
  created_at: string;
  detail: string;
  event_id?: string;
  actor_name?: string;
  actor_id?: string | null;
  payload?: Record<string, unknown>;
}

export interface HumanInterventionItem {
  description: string;
  actorName: string;
  created_at: string;
}

export interface ChallengeItem {
  statement: string;
  challengerRole: string;
  targetClaimCode: string | null;
  created_at: string;
  resolved: boolean;
}

export interface OutcomeItem {
  description: string;
  created_at: string;
}

export interface DecisionTrailExport {
  workspaceName: string;
  workspaceId?: string;
  category?: string | null;
  currentStatus?: string | null;
  generatedAt: string;
  openingQuestion: string | null;
  finalDecision: { status: string; actorName: string | null; timestamp: string } | null;
  rationale: string | null;
  initialRecommendation: string | null;
  evidence: EvidenceExportItem[];
  humanInterventions: HumanInterventionItem[];
  challenges: ChallengeItem[];
  openRisks: string[];
  outcomes: OutcomeItem[];
  events: TrailEventExportItem[];
  evidenceVersions?: EvidenceVersionExportItem[];
  snapshots?: SnapshotExportItem[];
  actorNames?: Record<string, string>;
}

export function exportDecisionTrailToPDF(data: DecisionTrailExport) {
  const freshnessBadge = (f: EvidenceExportItem['freshness']) => {
    const label = f === 'current' ? 'Current' : f === 'aging' ? 'Aging' : 'Stale';
    const cls = f === 'current' ? 'bb-sev-low' : f === 'aging' ? 'bb-sev-medium' : 'bb-sev-high';
    return `<span class="bb-badge ${cls}">${label}</span>`;
  };

  const classLabel = (c: string | null | undefined) => {
    if (!c) return 'Unclassified';
    const map: Record<string, string> = {
      verified_fact: 'Verified Fact',
      reported_fact: 'Reported Fact',
      assumption: 'Assumption',
      ai_inference: 'AI Inference',
      unverified_claim: 'Unverified Claim',
    };
    return map[c] || c;
  };

  const classColor = (c: string | null | undefined) => {
    const map: Record<string, string> = {
      verified_fact: '#16a34a',
      reported_fact: '#0891b2',
      assumption: '#d97706',
      ai_inference: '#2563eb',
      unverified_claim: '#dc2626',
    };
    return (c && map[c]) || '#64748b';
  };

  const vStatusLabel = (s: string | null | undefined) => {
    if (!s) return 'Not Verified';
    const map: Record<string, string> = {
      not_verified: 'Not Verified',
      pending: 'Pending',
      verified: 'Human Verified',
      failed: 'Failed',
      expired: 'Expired',
    };
    return map[s] || s;
  };

  const vStatusColor = (s: string | null | undefined) => {
    const map: Record<string, string> = {
      not_verified: '#64748b',
      pending: '#d97706',
      verified: '#16a34a',
      failed: '#dc2626',
      expired: '#b45309',
    };
    return (s && map[s]) || '#64748b';
  };

  const statusLabel = (s: string) =>
    ({ exploring: 'Exploring', in_debate: 'In Debate', committed: 'Committed', implemented: 'Implemented' } as Record<string, string>)[s] || s;

  const avgConfidence = data.evidence.length > 0
    ? Math.round((data.evidence.reduce((sum, c) => sum + c.confidence, 0) / data.evidence.length) * 100)
    : null;
  const staleCount = data.evidence.filter(c => c.freshness === 'stale').length;
  const agingCount = data.evidence.filter(c => c.freshness === 'aging').length;

  const evidenceHtml = data.evidence.map((c) => {
    const cls = classLabel(c.evidence_classification);
    const clsColor = classColor(c.evidence_classification);
    const vs = vStatusLabel(c.verification_status);
    const vsColor = vStatusColor(c.verification_status);
    const aiConf = c.ai_confidence_score != null ? ` · AI Confidence: ${Math.round(c.ai_confidence_score * 100)}%` : '';
    const sourceInfo = c.source_name ? ` · Source: ${escapeHtml(c.source_name)}` : '';
    const refInfo = c.source_reference ? ` · Ref: ${escapeHtml(c.source_reference)}` : '';
    const verifiedInfo = c.verification_status === 'verified' && c.verified_at
      ? ` · Verified ${escapeHtml(new Date(c.verified_at).toLocaleString())}${c.verified_by_name ? ` by ${escapeHtml(c.verified_by_name)}` : ''}`
      : ' · Not currently human-verified';
    const reviewInfo = c.last_reviewed_at ? ` · Reviewed ${new Date(c.last_reviewed_at).toLocaleDateString()}` : '';
    return `
    <div class="bb-row">
      <span class="bb-num" style="font-family:monospace;font-weight:800;min-width:52px;">${escapeHtml(c.claim_code)}</span>
      <div class="bb-text" style="flex:1;">
        ${escapeHtml(c.statement)}
        <div style="display:flex;flex-wrap:wrap;gap:4px;margin-top:3px;">
          <span style="font-size:7pt;font-weight:700;padding:1px 6px;border-radius:999px;background:${clsColor}1a;color:${clsColor};">${escapeHtml(cls)}</span>
          <span style="font-size:7pt;font-weight:700;padding:1px 6px;border-radius:999px;background:${vsColor}1a;color:${vsColor};">${escapeHtml(vs)}</span>
        </div>
        <div style="font-size:7pt;color:#94a3b8;margin-top:2px;">
          ${escapeHtml(c.agent_name)} · ${escapeHtml(c.claim_type)} · ${Math.round(c.confidence * 100)}% confidence${aiConf}${verifiedInfo}${sourceInfo}${refInfo}${reviewInfo}
        </div>
        ${c.verification_method ? `<div style="font-size:7pt;color:#94a3b8;margin-top:1px;">Method: ${escapeHtml(c.verification_method)}</div>` : ''}
      </div>
      ${c.verification_status === 'verified' ? freshnessBadge(c.freshness) : '<span class="bb-badge bb-sev-medium">Verification outstanding</span>'}
    </div>`;
  }).join('');

  const interventionsHtml = data.humanInterventions.map((h, i) => `
    <div class="bb-row">
      <span class="bb-num">${i + 1}.</span>
      <div style="flex:1;">
        <div class="bb-text">${escapeHtml(h.description)}</div>
        <div style="font-size:7pt;color:#94a3b8;margin-top:2px;">${escapeHtml(h.actorName)} · ${new Date(h.created_at).toLocaleString()}</div>
      </div>
    </div>`).join('');

  const challengesHtml = data.challenges.map((c, i) => `
    <div class="bb-row">
      <span class="bb-num">${i + 1}.</span>
      <div style="flex:1;">
        <div class="bb-text">${escapeHtml(c.statement)}</div>
        <div style="font-size:7pt;color:#94a3b8;margin-top:2px;">
          Raised by ${escapeHtml(c.challengerRole)}${c.targetClaimCode ? ` · targets ${escapeHtml(c.targetClaimCode)}` : ''} · ${new Date(c.created_at).toLocaleString()}
        </div>
      </div>
      <span class="bb-badge ${c.resolved ? 'bb-sev-low' : 'bb-sev-medium'}">${c.resolved ? 'Resolved' : 'Open'}</span>
    </div>`).join('');

  const risksHtml = data.openRisks.map((r, i) => `
    <div class="bb-row">
      <span class="bb-num">${i + 1}.</span>
      <div class="bb-text">${escapeHtml(r)}</div>
    </div>`).join('');

  const outcomesHtml = data.outcomes.map((o, i) => `
    <div class="bb-row">
      <span class="bb-num">${i + 1}.</span>
      <div style="flex:1;">
        <div class="bb-text">${escapeHtml(o.description)}</div>
        <div style="font-size:7pt;color:#94a3b8;margin-top:2px;">${new Date(o.created_at).toLocaleString()}</div>
      </div>
    </div>`).join('');

  // Preserve every stored event field. Values are HTML-escaped to prevent
  // user-provided notes and evidence from being interpreted as markup.
  const auditValue = (value: unknown): string => {
    if (value === null || value === undefined) return 'Not recorded';
    if (typeof value === 'string') return value || 'Not recorded';
    if (typeof value === 'number' || typeof value === 'boolean') return String(value);
    try { return JSON.stringify(value, null, 2); }
    catch { return 'Unable to display stored value'; }
  };
  const auditLabel = (key: string) => key.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
  // Use legible, time-based references in reports. UUIDs remain in the database.
  const auditRef = (prefix: 'EVT' | 'SNP', timestamp: string): string => {
    const d = new Date(timestamp);
    if (Number.isNaN(d.getTime())) return `${prefix}-UNKNOWN`;
    const pad = (n: number, w = 2) => String(n).padStart(w, '0');
    return `${prefix}-${d.getUTCFullYear()}${pad(d.getUTCMonth()+1)}${pad(d.getUTCDate())}-${pad(d.getUTCHours())}${pad(d.getUTCMinutes())}${pad(d.getUTCSeconds())}-${pad(d.getUTCMilliseconds(),3)}`;
  };

  // Only identity fields are resolved. Evidence, event and snapshot references
  // retain their audit meaning; unknown people are never guessed.
  const identityKeys = new Set([
    'created_by', 'modified_by', 'verified_by', 'reviewer_id',
    'changed_by', 'approved_by', 'actor_id', 'user_id', 'owner_user_id',
    'backup_owner_user_id', 'assigned_by', 'resolved_by', 'requested_by',
  ]);
  const isUuid = (value: string) => /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(value);
  const personName = (value: string): string =>
    data.actorNames?.[value] || (isUuid(value) ? 'Unknown user' : value);
  const readableIdentity = (key: string, value: unknown): unknown => {
    if (typeof value === 'string' && identityKeys.has(key.toLowerCase())) return personName(value);
    return value;
  };

  const fullEventsHtml = data.events.map((e, i) => {
    const fields = e.payload && typeof e.payload === 'object' ? Object.entries(e.payload) : [];
    const readablePayload = (key: string, value: unknown): string => {
      if (typeof value === 'string' && identityKeys.has(key.toLowerCase()))
        return personName(value);
      if (key === 'snapshot_id' && typeof value === 'string')
        return auditRef('SNP', e.created_at);
      return auditValue(readableIdentity(key, value));
    };
    const fieldsHtml = fields.map(([key, value]) => `
      <div style="margin:5px 0;break-inside:avoid;">
        <div style="font-size:7pt;font-weight:700;color:#475569;">${escapeHtml(auditLabel(key))}</div>
        <div style="font-size:8pt;white-space:pre-wrap;overflow-wrap:anywhere;word-break:break-word;">${escapeHtml(readablePayload(key, value))}</div>
      </div>`).join('');
    return `
    <div class="bb-row" style="break-inside:avoid;page-break-inside:avoid;align-items:flex-start;">
      <span class="bb-num">${i + 1}.</span>
      <div style="flex:1;min-width:0;">
        <div class="bb-text" style="font-weight:700;">${escapeHtml(e.label)}</div>
        <div style="font-size:7pt;color:#64748b;margin:3px 0;">
          Recorded ${escapeHtml(new Date(e.created_at).toLocaleString())} ·
          By ${escapeHtml(e.actor_name || 'Not recorded')}
        </div>
        ${e.detail ? `<div class="bb-text" style="margin-top:3px;white-space:pre-wrap;overflow-wrap:anywhere;">${escapeHtml(e.detail)}</div>` : ''}
        ${fieldsHtml || '<div style="font-size:7pt;color:#94a3b8;">No additional event payload was recorded.</div>'}
        <div style="font-size:6.5pt;color:#94a3b8;margin-top:5px;overflow-wrap:anywhere;">
          Event reference: ${escapeHtml(auditRef('EVT', e.created_at))}
        </div>
      </div>
    </div>`;
  }).join('');

  const versionsHtml = (data.evidenceVersions || []).map((v) => {
    const prevClass = classLabel(v.previous_classification);
    const newClass = classLabel(v.updated_classification);
    const prevStatus = vStatusLabel(v.previous_verification_status);
    const newStatus = vStatusLabel(v.updated_verification_status);
    return `
    <div class="bb-row">
      <span class="bb-num" style="font-family:monospace;font-weight:800;min-width:52px;">${escapeHtml(v.claim_code)} v${v.version_number}</span>
      <div class="bb-text" style="flex:1;">
        <div style="font-weight:700;margin-bottom:2px;">Reason: ${escapeHtml(v.reason_for_modification)}</div>
        ${v.previous_statement ? `<div style="font-size:8pt;color:#94a3b8;">Before: ${escapeHtml(v.previous_statement)}</div>` : ''}
        ${v.updated_statement ? `<div style="font-size:8pt;color:#334155;">After: ${escapeHtml(v.updated_statement)}</div>` : ''}
        ${(v.previous_classification || v.updated_classification) ? `<div style="font-size:7pt;color:#94a3b8;margin-top:2px;">Classification: ${escapeHtml(prevClass)} &rarr; ${escapeHtml(newClass)}</div>` : ''}
        ${(v.previous_verification_status || v.updated_verification_status) ? `<div style="font-size:7pt;color:#94a3b8;">Verification: ${escapeHtml(prevStatus)} &rarr; ${escapeHtml(newStatus)}</div>` : ''}
        <div style="font-size:7pt;color:#94a3b8;margin-top:2px;">${v.modified_by_name ? escapeHtml(v.modified_by_name) + ' · ' : ''}${new Date(v.modified_at).toLocaleString()}</div>
      </div>
    </div>`;
  }).join('');

  // Render captured snapshot data as readable, printable records rather than raw JSON.
  // Values come exclusively from the historical snapshot, never from current evidence.
  const snapshotLabel = (key: string): string => key
    .replace(/_/g, ' ')
    .replace(/\b\w/g, char => char.toUpperCase());

  const snapshotValue = (value: unknown): string => {
    if (value === null || value === undefined || value === '') return 'Not recorded';
    if (typeof value === 'boolean') return value ? 'Yes' : 'No';
    if (typeof value === 'number') return String(value);
    if (typeof value === 'string') return value;
    return '';
  };

  const snapshotContent = (value: unknown, depth = 0): string => {
    if (value === null || value === undefined) return '<span style="color:#94a3b8;">Not recorded</span>';
    if (Array.isArray(value)) {
      if (!value.length) return '<span style="color:#94a3b8;">None recorded</span>';
      return `<div style="display:block;">${value.map((item, i) => `
        <div style="padding:7px 9px;margin:5px 0;border:1px solid #e2e8f0;border-radius:5px;break-inside:avoid-page;page-break-inside:avoid;">
          <div style="font-weight:700;font-size:7.5pt;margin-bottom:4px;">Record ${i + 1}</div>
          ${snapshotContent(item, depth + 1)}
        </div>`).join('')}</div>`;
    }
    if (typeof value === 'object') {
      const fields = Object.entries(value as Record<string, unknown>);
      if (!fields.length) return '<span style="color:#94a3b8;">None recorded</span>';
      const claimCode = typeof (value as Record<string, unknown>).claim_code === 'string'
        ? String((value as Record<string, unknown>).claim_code) : null;
      return `<div style="width:100%;">${fields.map(([key, fieldValue]) => {
        // The claim code is the public evidence reference. Avoid printing
        // its internal database UUID as if it were a user-facing evidence ID.
        if (key === 'id' && claimCode && typeof fieldValue === 'string' && isUuid(fieldValue)) return '';
        const shownValue = readableIdentity(key, fieldValue);
        return `<div style="padding:4px 0;border-bottom:1px solid #f1f5f9;break-inside:auto;">
          <span style="display:block;font-size:7pt;font-weight:700;color:#475569;">${escapeHtml(snapshotLabel(key))}</span>
          <div style="font-size:8pt;line-height:1.5;white-space:pre-wrap;overflow-wrap:anywhere;">${snapshotContent(shownValue, depth + 1)}</div>
        </div>`;
      }).join('')}</div>`;
    }
    return escapeHtml(snapshotValue(value));
  };

  const snapshotDetail = (label: string, value: unknown): string => {
    if (value === null || value === undefined) return '';
    return `<div style="margin-top:12px;break-inside:auto;">
      <h3 style="font-size:9pt;font-weight:700;color:#0f172a;margin:0 0 6px;">${escapeHtml(label)}</h3>
      ${snapshotContent(value)}
    </div>`;
  };
  const snapshotsHtml = (data.snapshots || []).map((s, i) => `
    <div class="bb-row">
      <span class="bb-num">${i + 1}.</span>
      <div style="flex:1;">
        <div class="bb-text" style="font-weight:700;">${s.decision_question ? escapeHtml(s.decision_question) : 'Snapshot'} · ${escapeHtml(auditRef('SNP', s.snapshot_timestamp))}</div>
        <div style="font-size:7pt;color:#94a3b8;margin-top:2px;">
          Status: ${escapeHtml(s.decision_status || 'unknown')} ·
          Evidence: ${s.verified_facts_count} verified, ${s.reported_facts_count} reported, ${s.assumptions_count} assumptions, ${s.ai_inferences_count} AI inferences
          ${s.ai_recommendation ? ' · AI recommendation recorded' : ''}
        </div>
        <div style="font-size:7pt;color:#94a3b8;">${s.created_by_name ? escapeHtml(s.created_by_name) + ' · ' : ''}${new Date(s.snapshot_timestamp).toLocaleString()}</div>
        ${snapshotDetail('Evidence at capture', s.evidence_snapshot)}
        ${snapshotDetail('Verified facts', s.verified_facts)}
        ${snapshotDetail('Reported facts', s.reported_facts)}
        ${snapshotDetail('Assumptions', s.assumptions)}
        ${snapshotDetail('AI inferences', s.ai_inferences)}
        ${snapshotDetail('Outstanding uncertainties', s.outstanding_uncertainties)}
        ${snapshotDetail('Human approvals', s.human_approvals)}
        ${snapshotDetail('AI recommendation at capture', s.ai_recommendation)}
      </div>
    </div>`).join('');

  const body = `
    <div class="bb-page">
      <div class="bb-header">
        <h1>Decision Record: ${escapeHtml(data.workspaceName)}</h1>
        <p class="bb-sub">
          ${data.category ? escapeHtml(data.category) + ' · ' : ''}${data.currentStatus ? statusLabel(data.currentStatus) : ''} · Generated ${new Date(data.generatedAt).toLocaleString()}
        </p>
      </div>

      <div class="bb-section">
        <h2>1. Decision Under Consideration</h2>
        <p class="bb-text">${data.openingQuestion ? escapeHtml(data.openingQuestion) : 'No framing question was recorded for this decision.'}</p>
      </div>

      <div class="bb-section">
        <h2>2. Final Decision</h2>
        ${data.finalDecision ? `
          <p class="bb-text" style="font-weight:700;">Status: ${statusLabel(data.finalDecision.status)}</p>
          <p class="bb-text" style="font-size:7pt;color:#94a3b8;">
            ${data.finalDecision.actorName ? `Recorded by ${escapeHtml(data.finalDecision.actorName)} · ` : ''}${new Date(data.finalDecision.timestamp).toLocaleString()}
          </p>` : '<p class="bb-text">This decision has not reached a final, locked-in status yet.</p>'}
        ${!data.finalDecision ? '<p class="bb-text" style="font-size:8pt;color:#b35c10;font-style:italic;margin-top:6px;">This decision is still under review. The information below reflects the current state of deliberation and may change.</p>' : ''}
      </div>

      <div class="bb-section">
        <h2>3. ${data.finalDecision ? 'Decision Rationale (AI synthesis)' : 'Current Decision Rationale (AI synthesis)'}</h2>
        <p class="bb-text">${data.rationale && data.rationale !== data.initialRecommendation ? escapeHtml(data.rationale) : 'No separate rationale was recorded beyond the initial AI recommendation shown in Section 4.'}</p>
        <p class="bb-text" style="font-size:7pt;color:#94a3b8;margin-top:4px;">${data.finalDecision ? 'The rationale above is the AI synthesis that preceded the final human decision. The human decision-maker may have agreed with, modified, or rejected this recommendation.' : 'Reconstructed from the AI synthesis immediately preceding the current state.'}</p>
      </div>

      <div class="bb-section">
        <h2>4. What AI Agents Initially Recommended</h2>
        <p class="bb-text">${data.initialRecommendation ? escapeHtml(data.initialRecommendation) : 'No initial AI recommendation was recorded.'}</p>
        <p class="bb-text" style="font-size:7pt;color:#94a3b8;margin-top:4px;">This is the AI-generated recommendation. It does not represent the final decision, which is made by a human team member.</p>
      </div>

      <div class="bb-section">
        <h2>5. Supporting Evidence (${data.evidence.length} items${avgConfidence !== null ? `, ${avgConfidence}% avg. confidence` : ''})</h2>
        ${(staleCount + agingCount) > 0 ? `<p class="bb-text" style="color:#a8292a;font-weight:700;margin-bottom:6px;">⚠ ${staleCount} stale, ${agingCount} aging — worth re-verifying.</p>` : ''}
        <p class="bb-text" style="font-size:7pt;color:#94a3b8;margin-bottom:8px;">Evidence is classified as Verified Fact, Reported Fact, Assumption, AI Inference, or Unverified Claim. AI confidence scores do not constitute independent verification.</p>
        ${evidenceHtml || '<p class="bb-text">No evidence recorded.</p>'}
      </div>

      <div class="bb-section">
        <h2>6. Human Overrides & Changes (${data.humanInterventions.length})</h2>
        ${interventionsHtml || '<p class="bb-text">No manual human overrides were recorded.</p>'}
      </div>

      <div class="bb-section">
        <h2>7. Challenges Raised (${data.challenges.length})</h2>
        ${challengesHtml || '<p class="bb-text">No challenges were raised against the evidence.</p>'}
      </div>

      <div class="bb-section">
        <h2>8. Open Risks & Unresolved Uncertainty</h2>
        ${risksHtml || '<p class="bb-text">No unresolved risks identified from current evidence.</p>'}
      </div>

      <div class="bb-section">
        <h2>9. What Happened After</h2>
        ${outcomesHtml || '<p class="bb-text">No outcome has been logged for this decision yet.</p>'}
      </div>

      <div class="bb-section">
        <h2>10. Full Chronological Audit Trail (${data.events.length} events)</h2>
        ${fullEventsHtml || '<p class="bb-text">No events recorded.</p>'}
      </div>

      ${(data.evidenceVersions || []).length > 0 ? `
      <div class="bb-section">
        <h2>11. Evidence Version History (${(data.evidenceVersions || []).length} revisions)</h2>
        <p class="bb-text" style="font-size:7pt;color:#94a3b8;margin-bottom:8px;">Each revision preserves the previous state of the evidence, ensuring the decision trail remains auditable even as evidence is updated.</p>
        ${versionsHtml}
      </div>` : ''}

      ${(data.snapshots || []).length > 0 ? `
      <div class="bb-section">
        <h2>12. Decision Snapshots (${(data.snapshots || []).length} snapshots)</h2>
        <p class="bb-text" style="font-size:7pt;color:#94a3b8;margin-bottom:8px;">Snapshots capture the full state of the decision at a point in time, including all evidence classifications and the AI recommendation at that moment.</p>
        ${snapshotsHtml || '<p class="bb-text">No snapshots recorded.</p>'}
      </div>` : ''}
    </div>
  `;

  openPrintWindow(body, `Decision Record — ${data.workspaceName}`);
  logExport('decision_trail', data.workspaceName, data.workspaceId);
}
